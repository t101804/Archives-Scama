<script type="text/javascript">
	window.location="https://<?php echo $_SERVER['SERVER_NAME']; ?>";
</script>