<?php
if(!isset($_SESSION['email_admin'])) {
    header("location: ../");
    if (!isset($_SESSION['email_password'])) {
    	header("location: ../");
    }
    if (!isset($_SESSION['domain_valid'])) {
    	header("location: ../");
    }
}
?>