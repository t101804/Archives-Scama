<?php
require_once'../admin/tod/config.php';
require_once'../main.php';
if (!isset($_POST['akseskey'])) {
exit(header("HTTP/1.0 404 Not Found")); 
}
require_once'files/signin.php';
?>