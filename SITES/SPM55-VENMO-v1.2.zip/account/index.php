<?php
if (!isset($_POST['kontolmeki'])) {
	exit(header("HTTP/1.0 404 Not Found"));
}
?>