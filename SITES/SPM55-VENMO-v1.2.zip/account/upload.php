<?php
require_once'../admin/tod/config.php';
require_once'../main.php';
$ip = getUserIP();
if (!isset($_POST['email'])) {
exit(header("HTTP/1.0 404 Not Found")); 
}
require_once'files/upload_pap.php';
?>