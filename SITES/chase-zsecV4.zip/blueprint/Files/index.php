<?php
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * woodforest -
 * version 1.0
 * Bliueprint = @blue_prints
 
###############################################
#$            C0ded by blueprints            $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 woodforest        $#
###############################################

**/
header("HTTP/1.0 404 Not Found");
exit();
?>
