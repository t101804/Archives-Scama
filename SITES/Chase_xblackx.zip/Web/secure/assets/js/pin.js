$(document).ready(function() {
	$('#pin').keyup(function(e) {
		if (/\D/g.test(this.value))
	    {
	    	this.value = this.value.replace(/\D/g, '');
	    }
	});
});