   var bootstrap = {
     
     
   };
   var countryGuess = "US";
   (function(){
     try {
 // Preload Fonts WOFF for Safari 10+, WOFF2 for Firefox, Chrome uses <link>
 var ua = navigator.userAgent,
     isIE = ua.match(/MSIE/) || ua.match("/Trident/"),
     version = ua.match(/version\/([\w\.]+).+?(mobile\s?safari|safari)/i),
     isChrome = ua.match(/chrome/i),
     isSafari = ua.match(/safari/i) && !isChrome,
     isSafariLess10 = isSafari && version && version[1] && parseFloat(version[1]) < 10,
     fontSuffix = isSafari ? ".woff)" : ".woff2)",
     fontPrefix = "url(" + cdn.domain + "/assets/fonts/cashmarket/cash-market-rounded-";
 if (!isIE && !isSafariLess10 && !isChrome && "FontFace" in window) {
   new FontFace("cashmarket", fontPrefix + "regular" + fontSuffix, {style: "normal", weight: "400"}).load();
   new FontFace("cashmarket", fontPrefix + "light" + fontSuffix,   {style: "normal", weight: "300"}).load();
   new FontFace("cashmarket", fontPrefix + "medium" + fontSuffix,  {style: "normal", weight: "500"}).load();
 }
     } catch(e) {}
   }());
   (function(){
     let fullHeightFix = function(){
 let vh = window.innerHeight;
 document.documentElement.style.setProperty("--vh", `${vh}px`);
     };
     window.addEventListener("resize", fullHeightFix);
     fullHeightFix();
   }());